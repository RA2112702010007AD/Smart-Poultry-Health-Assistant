# Poultry Disease Prediction System

A machine learning model for early detection and prediction of poultry diseases using advanced sensor data analysis and classification techniques.

## Key Features

- Python-based machine learning model for disease prediction
- Real-time dashboard for environmental monitoring
- Comprehensive model evaluation metrics
- Email notification system for disease alerts
- Interactive charts and visualizations

## Getting Started

1. Run the Streamlit application:
   ```
   streamlit run app.py
   ```

2. Navigate to the different sections using the sidebar menu:
   - **Dashboard**: View real-time environmental data and predictions
   - **Manual Prediction**: Enter your own environmental parameters
   - **Model Evaluation**: See detailed model metrics and performance
   - **Settings**: Configure email notifications and thresholds
   - **About**: Learn more about the system

## Setting Up Email Notifications

The system can send email alerts when a disease is predicted with high confidence. To set up this feature:

1. Go to the **Settings** page in the application
2. Enter your SMTP server details (e.g., smtp.gmail.com)
3. Provide your email credentials
   - For Gmail, you'll need to create an "App Password" for security
   - Visit: https://myaccount.google.com/apppasswords
4. Set your notification preferences:
   - Confidence threshold
   - Recipient email (default: jenniearul@gmail.com)

Alternatively, you can create a `.env` file in the root directory with your credentials (see `.env.example` for a template).

## Environmental Parameters

The system monitors the following environmental parameters:

- **Temperature**: Measured in °C
- **Humidity**: Percentage of water vapor in the air
- **CO2 Levels**: Measured in parts per million (ppm)
- **Ammonia Levels**: Measured in parts per million (ppm)

## Disease Prediction

The system uses a Random Forest classifier trained on environmental data to predict the following poultry diseases:

- Avian Influenza
- Newcastle Disease
- Chronic Respiratory Disease (CRD)
- Infectious Bronchitis
- Heat Stroke
- Pneumonia/Fungal
- Aspergillosis
- Omphilitispis
- Healthy (no disease)

## Model Performance

- Overall accuracy: ~88%
- Best performance on detecting:
  - Healthy birds (100% precision/recall)
  - Avian Influenza (85.11% F1-score)
- Areas for improvement:
  - New Castle disease detection (55% recall)
  - CRD (70.59% precision)

For detailed metrics, visit the Model Evaluation page in the application.