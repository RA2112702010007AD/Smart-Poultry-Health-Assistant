"""
Simplified model evaluation script that generates metrics and visualizations
for the poultry disease prediction model
"""

import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix
)

def evaluate_model(model_path='poultry_disease_prediction_model.pkl', n_samples=200):
    """
    Evaluate the trained model and return metrics and visualizations
    """
    # Load the model
    try:
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        model = model_data['model']
        scaler = model_data['scaler']
        features = model_data['features']
        disease_id_to_name = model_data['disease_id_to_name']
    except FileNotFoundError:
        return {"error": "Model file not found. Please train the model first."}
    
    # Generate test data using the same process as in quick_train_model.py
    # Set up disease categories - similar distribution to training
    disease_ids = [0] * 100 + [1] * 20 + [2] * 20 + [7] * 20 + [9] * 20 + [12] * 20
    np.random.shuffle(disease_ids)
    disease_ids = disease_ids[:n_samples]  # Make sure we have n_samples
    
    # Get disease names
    disease_names = [disease_id_to_name.get(id, f"Unknown ({id})") for id in disease_ids]
    
    # Generate environmental conditions based on disease
    temperatures = []
    humidities = []
    co2_levels = []
    ammonia_levels = []
    bird_ages = []
    seasons = ['summer', 'winter', 'rainy', 'spring']
    season_list = []
    
    for i, disease_id in enumerate(disease_ids):
        if disease_id == 0:  # Healthy
            temp = np.random.uniform(26, 28)
            humidity = np.random.uniform(50, 60)
            co2 = np.random.uniform(1000, 3000)
            ammonia = np.random.uniform(5, 15)
        elif disease_id == 1:  # Pneumonia/Fungal
            temp = np.random.uniform(30, 34)
            humidity = np.random.uniform(70, 90)
            co2 = np.random.uniform(2500, 4000)
            ammonia = np.random.uniform(10, 25)
        elif disease_id == 2:  # Omphilitispis
            temp = np.random.uniform(28, 33)
            humidity = np.random.uniform(65, 85)
            co2 = np.random.uniform(3000, 4500)
            ammonia = np.random.uniform(15, 30)
        elif disease_id == 7:  # CRD
            temp = np.random.uniform(30, 38)
            humidity = np.random.uniform(40, 70)
            co2 = np.random.uniform(2500, 4500)
            ammonia = np.random.uniform(20, 40)
        elif disease_id == 9:  # Heat Stroke
            temp = np.random.uniform(33, 42)
            humidity = np.random.uniform(40, 70)
            co2 = np.random.uniform(2000, 5000)
            ammonia = np.random.uniform(15, 30)
        elif disease_id == 12:  # New Castle
            temp = np.random.uniform(28, 36)
            humidity = np.random.uniform(50, 80)
            co2 = np.random.uniform(2500, 4500)
            ammonia = np.random.uniform(20, 35)
        else:  # Other diseases (shouldn't happen in this simplified case)
            temp = np.random.uniform(25, 35)
            humidity = np.random.uniform(50, 80)
            co2 = np.random.uniform(2000, 4500)
            ammonia = np.random.uniform(10, 30)
        
        # Add some random noise
        temp += np.random.normal(0, 0.5)
        humidity += np.random.normal(0, 2)
        co2 += np.random.normal(0, 100)
        ammonia += np.random.normal(0, 1)
        
        # Clamp to reasonable ranges
        temperatures.append(max(15, min(45, temp)))
        humidities.append(max(30, min(95, humidity)))
        co2_levels.append(max(400, min(6000, co2)))
        ammonia_levels.append(max(0, min(50, ammonia)))
        
        # Random bird age (1-40 days)
        bird_ages.append(np.random.randint(1, 41))
        
        # Random season
        season_list.append(np.random.choice(seasons))
    
    # Create test DataFrame
    test_data = pd.DataFrame({
        'temperature': temperatures,
        'humidity': humidities,
        'co2': co2_levels,
        'ammonia': ammonia_levels,
        'bird_age': bird_ages,
        'season': season_list,
        'disease_id': disease_ids,
        'disease_name': disease_names
    })
    
    # Process test data (same as in training)
    
    # One-hot encode season
    test_data = pd.get_dummies(test_data, columns=['season'], prefix='season')
    
    # Create THI feature
    test_data['THI'] = (0.8 * test_data['temperature'] + 
                       (test_data['humidity'] / 100) * 
                       (test_data['temperature'] - 14.4) + 46.4)
    
    # Create threshold breach indicators
    test_data['temp_above_threshold'] = (test_data['temperature'] > 31).astype(int)
    test_data['co2_above_threshold'] = (test_data['co2'] > 3500).astype(int)
    test_data['ammonia_above_threshold'] = (test_data['ammonia'] > 25).astype(int)
    test_data['humidity_below_threshold'] = (test_data['humidity'] < 50).astype(int)
    test_data['humidity_above_threshold'] = (test_data['humidity'] > 60).astype(int)
    
    # Extract features and target
    X_test = test_data.drop(['disease_id', 'disease_name'], axis=1)
    y_test = test_data['disease_id']
    
    # Ensure all features from the model are present in the test data
    for feature in features:
        if feature not in X_test.columns:
            X_test[feature] = 0  # Set default value for missing features
    
    # Ensure the features are in the same order as the model expects
    X_test = X_test[features]
    
    # Scale the test data
    X_test_scaled = scaler.transform(X_test)
    
    # Make predictions
    y_pred = model.predict(X_test_scaled)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    
    # Get precision, recall, and F1 score for each class
    present_classes = sorted(list(set(y_test) | set(y_pred)))
    present_class_names = [disease_id_to_name.get(i, f"Unknown ({i})") for i in present_classes]
    
    report = classification_report(y_test, y_pred, target_names=present_class_names, output_dict=True)
    report_df = pd.DataFrame(report).transpose()
    
    # Create a pandas DataFrame for easier reporting
    metrics_df = pd.DataFrame({
        'Disease': [disease_id_to_name.get(i, f"Unknown ({i})") for i in present_classes],
        'Precision': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['precision'] for i in present_classes],
        'Recall': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['recall'] for i in present_classes],
        'F1-Score': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['f1-score'] for i in present_classes],
        'Support': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['support'] for i in present_classes]
    })
    
    # Calculate overall weighted metrics
    weighted_precision = precision_score(y_test, y_pred, average='weighted')
    weighted_recall = recall_score(y_test, y_pred, average='weighted')
    weighted_f1 = f1_score(y_test, y_pred, average='weighted')
    
    # Create confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    
    # Generate confusion matrix visualization
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=present_class_names,
                yticklabels=present_class_names)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    confusion_matrix_fig = plt.gcf()
    
    # Feature importance plot
    plt.figure(figsize=(12, 6))
    feature_importance = pd.DataFrame({
        'Feature': features,
        'Importance': model.feature_importances_
    }).sort_values('Importance', ascending=False)
    
    sns.barplot(x='Importance', y='Feature', data=feature_importance.head(15))
    plt.title('Top 15 Feature Importance')
    feature_importance_fig = plt.gcf()
    
    # Generate precision, recall, f1 visualization
    plt.figure(figsize=(10, 6))
    metrics_plot = metrics_df.set_index('Disease').iloc[:, 0:3]
    metrics_plot.plot(kind='bar', figsize=(12, 6))
    plt.title('Precision, Recall, and F1-Score by Disease')
    plt.ylim(0, 1.0)
    plt.xticks(rotation=45)
    plt.tight_layout()
    metrics_fig = plt.gcf()
    
    # Return dictionary of all results
    return {
        "accuracy": accuracy,
        "weighted_precision": weighted_precision,
        "weighted_recall": weighted_recall,
        "weighted_f1": weighted_f1,
        "metrics_by_class": metrics_df,
        "confusion_matrix": cm,
        "confusion_matrix_fig": confusion_matrix_fig,
        "feature_importance": feature_importance,
        "feature_importance_fig": feature_importance_fig,
        "metrics_fig": metrics_fig,
        "disease_id_to_name": disease_id_to_name,
        "present_classes": present_classes
    }