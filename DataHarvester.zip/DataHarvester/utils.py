"""
Utility functions for poultry disease prediction model
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Define standard thresholds from the document
thresholds = {
    "co2": {"max": 3500, "critical": 5000},  # ppm
    "temperature": {"ideal": 27.5, "max": 31},  # Celsius
    "co": {"max": 800},  # Carbon Monoxide (ppm)
    "ammonia": {"max": 25},  # ppm
    "humidity": {"min": 50, "max": 60},  # percentage (RH)
    "water_hardness": {"max": 300},  # ppm
    "water_ph": {"ideal": 6.5}  # pH
}

# Information about poultry diseases
diseases_info = [
    {
        "id": 1,
        "name": "Pneumonia/Fungal",
        "age_range": [1, 7],  # days
        "season": ["rainy", "winter", "summer"],  # more in rainy and winter
        "symptoms": ["lethargic", "gasping", "inappetent", "high_mortality"],
        "cause": "fungal",
        "temp_range": [30, 34],  # Celsius
        "humidity_range": [70, 90],  # percentage
        "co2_range": [2500, 4000],  # ppm
        "ammonia_range": [10, 25]  # ppm
    },
    {
        "id": 2,
        "name": "Omphilitispis",
        "age_range": [1, 8],
        "season": ["rainy", "winter", "summer"],
        "symptoms": ["naval_infection", "pastely_vent", "closed_eyes", "attracted_to_heat"],
        "cause": "bacterial",
        "temp_range": [28, 33],
        "humidity_range": [65, 85],
        "co2_range": [3000, 4500],
        "ammonia_range": [15, 30]
    },
    {
        "id": 3,
        "name": "Hurdlling",
        "age_range": [1, 2],
        "season": ["winter"],
        "symptoms": ["spread_over_bruder"],
        "cause": "environmental",
        "temp_range": [26, 36],  # Either too high or too low
        "humidity_range": [50, 80],
        "co2_range": [2000, 4000],
        "ammonia_range": [5, 20]
    },
    {
        "id": 4,
        "name": "Gout",
        "age_range": [6, 12],
        "season": ["rainy", "winter"],
        "symptoms": ["no_mobility", "white_diarrhea", "sudden_death"],
        "cause": "metabolic",
        "temp_range": [24, 30],
        "humidity_range": [60, 85],
        "co2_range": [2500, 4500],
        "ammonia_range": [10, 25]
    },
    {
        "id": 5,
        "name": "IBD",
        "age_range": [9, 12],
        "season": ["rainy", "winter"],
        "symptoms": ["depression", "ruffled_feathers", "white_diarrhea", "vent_picking"],
        "cause": "viral",
        "temp_range": [22, 32],
        "humidity_range": [60, 85],
        "co2_range": [2500, 4000],
        "ammonia_range": [15, 30]
    },
    {
        "id": 6,
        "name": "Cacoccidiosis",
        "age_range": [14, 18],
        "season": ["rainy"],
        "symptoms": ["bleeding", "mucus_in_droppings", "weight_loss"],
        "cause": "protozoal",
        "temp_range": [25, 32],
        "humidity_range": [75, 95],
        "co2_range": [2000, 4000],
        "ammonia_range": [10, 25]
    },
    {
        "id": 7,
        "name": "CRD",
        "age_range": [18, 35],
        "season": ["summer"],
        "symptoms": ["facial_swelling", "coughing", "wheezing", "pus"],
        "cause": "bacterial",
        "temp_range": [30, 38],
        "humidity_range": [40, 70],
        "co2_range": [2500, 4500],
        "ammonia_range": [20, 40]  # Main concern
    },
    {
        "id": 8,
        "name": "Colli Basilocious",
        "age_range": [1, 7],
        "season": ["rainy", "winter", "summer"],
        "symptoms": ["pericordities", "ompholitious", "white_layer_on_liver"],
        "cause": "bacterial",
        "temp_range": [25, 34],
        "humidity_range": [50, 85],
        "co2_range": [2000, 4000],
        "ammonia_range": [5, 25]
    },
    {
        "id": 9,
        "name": "Avian Influenza",
        "age_range": [1, 40],
        "season": ["summer", "winter"],
        "symptoms": ["sneezing", "coughing", "diarrhea", "high_mortality"],
        "cause": "viral",
        "temp_range": [30, 40],  # High temperature
        "humidity_range": [40, 80],
        "co2_range": [2500, 4500],
        "ammonia_range": [20, 40]  # Ammonia cause
    },
    {
        "id": 10,
        "name": "Heat Stroke",
        "age_range": [1, 40],
        "season": ["summer"],
        "symptoms": ["panting", "decreased_intake", "spread_wings", "open_mouth_breathing"],
        "cause": "environmental",
        "temp_range": [33, 42],  # High temperature
        "humidity_range": [40, 70],
        "co2_range": [2000, 5000],
        "ammonia_range": [15, 30]
    },
    {
        "id": 11,
        "name": "Asscites",
        "age_range": [7, 40],
        "season": ["winter"],
        "symptoms": ["metabolic_disorder", "insufficient_oxygen"],
        "cause": "environmental",
        "temp_range": [20, 28],
        "humidity_range": [60, 85],
        "co2_range": [3500, 6000],  # High CO2
        "ammonia_range": [25, 40]  # High ammonia
    },
    {
        "id": 12,
        "name": "New Castle",
        "age_range": [1, 40],
        "season": ["summer", "rainy", "winter"],  # Most in summer
        "symptoms": ["sudden_death", "high_mortality", "gasping", "greenish_diarrhea"],
        "cause": "viral",
        "temp_range": [28, 36],
        "humidity_range": [50, 80],
        "co2_range": [2500, 4500],
        "ammonia_range": [20, 35]  # Ammonia cause
    },
    {
        "id": 13,
        "name": "Tortticollies",
        "age_range": [5, 30],
        "season": ["rainy", "winter", "summer"],
        "symptoms": ["respiratory", "nerve", "brain"],
        "cause": "neural_syndrome",
        "temp_range": [25, 35],
        "humidity_range": [50, 85],
        "co2_range": [2500, 4500],
        "ammonia_range": [15, 30]
    },
    {
        "id": 14,
        "name": "Infectious Bronchitis",
        "age_range": [7, 40],
        "season": ["rainy", "winter", "summer"],
        "symptoms": ["sneezing", "coughing", "gout", "kidney_damage", "gut_damage"],
        "cause": "viral",
        "temp_range": [30, 40],  # High temperature
        "humidity_range": [50, 80],
        "co2_range": [2500, 4500],
        "ammonia_range": [20, 35]  # Ammonia cause
    },
    {
        "id": 0,  # A special ID for "Healthy" state
        "name": "Healthy",
        "age_range": [1, 40],
        "season": ["rainy", "winter", "summer"],
        "symptoms": ["normal"],
        "cause": "normal",
        "temp_range": [26, 28],  # Ideal temperature
        "humidity_range": [50, 60],  # Ideal humidity
        "co2_range": [1000, 3000],  # Ideal CO2
        "ammonia_range": [5, 15]  # Ideal ammonia
    }
]

def get_seasons():
    """Return a list of seasons"""
    return ["summer", "winter", "rainy", "spring"]

def get_disease_ids_and_names():
    """Return a dictionary mapping disease IDs to names"""
    return {disease["id"]: disease["name"] for disease in diseases_info}

def generate_synthetic_data(n_samples=100, start_date="2023-01-01", end_date="2023-12-31"):
    """
    Generate synthetic sensor data based on the disease information.
    
    Parameters:
    - n_samples: Number of samples to generate
    - start_date: Start date for the time series
    - end_date: End date for the time series
    
    Returns:
    - df: Pandas DataFrame with synthetic sensor data
    """
    # Convert dates to datetime objects
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)
    
    # Generate random timestamps
    date_range = (end_date - start_date).days
    random_days = np.random.randint(0, date_range, n_samples)
    timestamps = [start_date + timedelta(days=int(day)) for day in random_days]
    timestamps.sort()
    
    # Determine season for each timestamp
    seasons = []
    for ts in timestamps:
        month = ts.month
        if 3 <= month <= 5:
            seasons.append("spring")
        elif 6 <= month <= 8:
            seasons.append("summer")
        elif 9 <= month <= 11:
            seasons.append("rainy")  # Assuming rainy/fall
        else:
            seasons.append("winter")
    
    # Generate bird age (in days) - Assuming a typical 6-week cycle for broilers
    bird_ages = []
    current_batch_start = start_date
    batch_age = 0
    batch_duration = 42  # 6 weeks
    
    for ts in timestamps:
        days_since_start = (ts - current_batch_start).days
        if days_since_start >= batch_duration:
            # Start a new batch
            current_batch_start = current_batch_start + timedelta(days=batch_duration + 7)  # 1 week downtime
            days_since_start = (ts - current_batch_start).days
        
        if days_since_start < 0:
            # Downtime period
            bird_ages.append(0)  # No birds during downtime
        else:
            bird_ages.append(days_since_start + 1)  # +1 because day 1 is the first day
    
    # Initialize data lists
    temperatures = []
    humidities = []
    co2_levels = []
    ammonia_levels = []
    disease_ids = []
    disease_names = []
    
    # Generate sensor data based on bird age and season
    for i in range(n_samples):
        age = bird_ages[i]
        season = seasons[i]
        
        if age == 0:
            # Downtime (no birds)
            temp = np.random.uniform(20, 25)
            humidity = np.random.uniform(40, 60)
            co2 = np.random.uniform(500, 1500)
            ammonia = np.random.uniform(0, 10)
            disease_id = -1  # No disease during downtime
            disease_name = "Downtime"
        else:
            # Determine potential diseases based on age and season
            potential_diseases = []
            for disease in diseases_info:
                if (disease["age_range"][0] <= age <= disease["age_range"][1] and 
                    season in disease["season"]):
                    potential_diseases.append(disease)
            
            # Randomly select disease or healthy state
            if potential_diseases and np.random.random() < 0.7:  # 70% chance of disease if potential diseases exist
                disease = np.random.choice(potential_diseases)
                disease_id = disease["id"]
                disease_name = disease["name"]
                
                # Generate sensor values within disease range
                temp = np.random.uniform(disease["temp_range"][0], disease["temp_range"][1])
                humidity = np.random.uniform(disease["humidity_range"][0], disease["humidity_range"][1])
                co2 = np.random.uniform(disease["co2_range"][0], disease["co2_range"][1])
                ammonia = np.random.uniform(disease["ammonia_range"][0], disease["ammonia_range"][1])
            else:
                # Healthy state
                healthy = diseases_info[-1]  # Last entry is the healthy state
                disease_id = healthy["id"]
                disease_name = healthy["name"]
                
                # Generate sensor values within healthy range
                temp = np.random.uniform(healthy["temp_range"][0], healthy["temp_range"][1])
                humidity = np.random.uniform(healthy["humidity_range"][0], healthy["humidity_range"][1])
                co2 = np.random.uniform(healthy["co2_range"][0], healthy["co2_range"][1])
                ammonia = np.random.uniform(healthy["ammonia_range"][0], healthy["ammonia_range"][1])
                
                # Add some noise
                temp += np.random.normal(0, 0.5)
                humidity += np.random.normal(0, 2)
                co2 += np.random.normal(0, 200)
                ammonia += np.random.normal(0, 2)
        
        # Append to lists
        temperatures.append(max(15, min(45, temp)))  # Clamp to reasonable range
        humidities.append(max(30, min(95, humidity)))
        co2_levels.append(max(400, min(6000, co2)))
        ammonia_levels.append(max(0, min(50, ammonia)))
        disease_ids.append(disease_id)
        disease_names.append(disease_name)
    
    # Create DataFrame
    df = pd.DataFrame({
        'timestamp': timestamps,
        'temperature': temperatures,
        'humidity': humidities,
        'co2': co2_levels,
        'ammonia': ammonia_levels,
        'bird_age': bird_ages,
        'season': seasons,
        'disease_id': disease_ids,
        'disease_name': disease_names
    })
    
    # Introduce some missing values to simulate real-world data
    for col in ['temperature', 'humidity', 'co2', 'ammonia']:
        mask = np.random.random(len(df)) < 0.05  # 5% missing values
        df.loc[mask, col] = np.nan
    
    return df
