"""
Email notification service for the Poultry Disease Prediction System.
This module sends alerts when diseases are detected.
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import os
import logging
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

class NotificationService:
    """Notification service for disease alerts"""
    
    def __init__(self, recipient_email="jenniearul@gmail.com"):
        """
        Initialize the notification service
        
        Args:
            recipient_email (str): Email address to send notifications to
        """
        self.recipient_email = recipient_email
        
    def send_disease_alert(self, disease_name, confidence, environmental_data, triggers):
        """
        Log a disease alert (actual email sending is disabled)
        
        Args:
            disease_name (str): Name of the predicted disease
            confidence (float): Prediction confidence (0-1)
            environmental_data (dict): Current environmental readings
            triggers (str): Trigger messages and recommendations
            
        Returns:
            bool: Always returns True (simulating successful notification)
        """
        # Format the alert message
        alert_message = f"""
        ========== POULTRY DISEASE ALERT ==========
        
        Disease: {disease_name}
        Confidence: {confidence:.2%}
        Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Environmental Conditions:
        - Temperature: {environmental_data.get('temperature', 'N/A')} °C
        - Humidity: {environmental_data.get('humidity', 'N/A')} %
        - CO2: {environmental_data.get('co2', 'N/A')} ppm
        - Ammonia: {environmental_data.get('ammonia', 'N/A')} ppm
        
        Triggers and Recommendations:
        {triggers}
        
        >>> Email notification would be sent to: {self.recipient_email}
        ===========================================
        """
        
        # Log the notification
        logger.info(f"Email notification would be sent to {self.recipient_email}")
        logger.info("Disease detected: %s (confidence: %.2f)", disease_name, confidence)
        print(alert_message)
        
        # In a real application, we would send an actual email here
        # But for this demo, we're just simulating the notification
        return True

# Create a global instance of the notification service
notification_service = NotificationService()

def send_disease_notification(disease_name, confidence, environmental_data, triggers):
    """
    Send a disease notification
    
    Args:
        disease_name (str): Name of the predicted disease
        confidence (float): Prediction confidence (0-1)
        environmental_data (dict): Current environmental readings
        triggers (str): Trigger messages and recommendations
        
    Returns:
        bool: True if notification was sent successfully
    """
    return notification_service.send_disease_alert(
        disease_name=disease_name,
        confidence=confidence,
        environmental_data=environmental_data,
        triggers=triggers
    )