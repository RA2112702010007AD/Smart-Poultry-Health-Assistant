"""
Poultry Disease Prediction Model Evaluation
This script evaluates the trained model using various metrics including:
- Accuracy
- Precision (for each class and weighted average)
- Recall (for each class and weighted average)
- F1 Score (for each class and weighted average)
- Confusion Matrix
"""

import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix, ConfusionMatrixDisplay
)

# Load the model
print("Loading the trained model...")
try:
    with open('poultry_disease_prediction_model.pkl', 'rb') as f:
        model_data = pickle.load(f)
    
    model = model_data['model']
    scaler = model_data['scaler']
    features = model_data['features']
    disease_id_to_name = model_data['disease_id_to_name']
    print("Model loaded successfully!")
except FileNotFoundError:
    print("Error: Model file not found. Please run quick_train_model.py first.")
    exit(1)

# Generate test data using the same process as in quick_train_model.py
# This ensures the evaluation is consistent with the training data
print("\nGenerating test data for evaluation...")

# Define function to generate synthetic test data similar to training data
def generate_test_data(n_samples=200):
    """Generate synthetic test data for model evaluation"""
    # Set up disease categories - similar distribution to training
    disease_ids = [0] * 100 + [1] * 20 + [2] * 20 + [7] * 20 + [9] * 20 + [12] * 20
    np.random.shuffle(disease_ids)
    disease_ids = disease_ids[:n_samples]  # Make sure we have n_samples
    
    # Get disease names
    disease_names = [disease_id_to_name.get(id, f"Unknown ({id})") for id in disease_ids]
    
    # Generate environmental conditions based on disease
    temperatures = []
    humidities = []
    co2_levels = []
    ammonia_levels = []
    bird_ages = []
    seasons = ['summer', 'winter', 'rainy', 'spring']
    season_list = []
    
    for i, disease_id in enumerate(disease_ids):
        if disease_id == 0:  # Healthy
            temp = np.random.uniform(26, 28)
            humidity = np.random.uniform(50, 60)
            co2 = np.random.uniform(1000, 3000)
            ammonia = np.random.uniform(5, 15)
        elif disease_id == 1:  # Pneumonia/Fungal
            temp = np.random.uniform(30, 34)
            humidity = np.random.uniform(70, 90)
            co2 = np.random.uniform(2500, 4000)
            ammonia = np.random.uniform(10, 25)
        elif disease_id == 2:  # Omphilitispis
            temp = np.random.uniform(28, 33)
            humidity = np.random.uniform(65, 85)
            co2 = np.random.uniform(3000, 4500)
            ammonia = np.random.uniform(15, 30)
        elif disease_id == 7:  # CRD
            temp = np.random.uniform(30, 38)
            humidity = np.random.uniform(40, 70)
            co2 = np.random.uniform(2500, 4500)
            ammonia = np.random.uniform(20, 40)
        elif disease_id == 9:  # Heat Stroke
            temp = np.random.uniform(33, 42)
            humidity = np.random.uniform(40, 70)
            co2 = np.random.uniform(2000, 5000)
            ammonia = np.random.uniform(15, 30)
        elif disease_id == 12:  # New Castle
            temp = np.random.uniform(28, 36)
            humidity = np.random.uniform(50, 80)
            co2 = np.random.uniform(2500, 4500)
            ammonia = np.random.uniform(20, 35)
        else:  # Other diseases (shouldn't happen in this simplified case)
            temp = np.random.uniform(25, 35)
            humidity = np.random.uniform(50, 80)
            co2 = np.random.uniform(2000, 4500)
            ammonia = np.random.uniform(10, 30)
        
        # Add some random noise
        temp += np.random.normal(0, 0.5)
        humidity += np.random.normal(0, 2)
        co2 += np.random.normal(0, 100)
        ammonia += np.random.normal(0, 1)
        
        # Clamp to reasonable ranges
        temperatures.append(max(15, min(45, temp)))
        humidities.append(max(30, min(95, humidity)))
        co2_levels.append(max(400, min(6000, co2)))
        ammonia_levels.append(max(0, min(50, ammonia)))
        
        # Random bird age (1-40 days)
        bird_ages.append(np.random.randint(1, 41))
        
        # Random season
        season_list.append(np.random.choice(seasons))
    
    # Create test DataFrame
    data = pd.DataFrame({
        'temperature': temperatures,
        'humidity': humidities,
        'co2': co2_levels,
        'ammonia': ammonia_levels,
        'bird_age': bird_ages,
        'season': season_list,
        'disease_id': disease_ids,
        'disease_name': disease_names
    })
    
    return data

# Generate test data
test_data = generate_test_data(200)
print(f"Generated {len(test_data)} test samples")

# Process test data (same as in training)
print("\nPreprocessing test data...")

# One-hot encode season
test_data = pd.get_dummies(test_data, columns=['season'], prefix='season')

# Create THI feature
test_data['THI'] = (0.8 * test_data['temperature'] + 
                    (test_data['humidity'] / 100) * 
                    (test_data['temperature'] - 14.4) + 46.4)

# Create threshold breach indicators
test_data['temp_above_threshold'] = (test_data['temperature'] > 31).astype(int)
test_data['co2_above_threshold'] = (test_data['co2'] > 3500).astype(int)
test_data['ammonia_above_threshold'] = (test_data['ammonia'] > 25).astype(int)
test_data['humidity_below_threshold'] = (test_data['humidity'] < 50).astype(int)
test_data['humidity_above_threshold'] = (test_data['humidity'] > 60).astype(int)

# Extract features and target
X_test = test_data.drop(['disease_id', 'disease_name'], axis=1)
y_test = test_data['disease_id']

# Ensure all features from the model are present in the test data
for feature in features:
    if feature not in X_test.columns:
        X_test[feature] = 0  # Set default value for missing features

# Ensure the features are in the same order as the model expects
X_test = X_test[features]

# Scale the test data
X_test_scaled = scaler.transform(X_test)

# Make predictions
print("\nMaking predictions on test data...")
y_pred = model.predict(X_test_scaled)

# Calculate metrics
print("\n===== Model Evaluation Results =====")
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Get precision, recall, and F1 score for each class
print("\nDetailed Classification Report:")
class_names = [disease_id_to_name.get(i, f"Unknown ({i})") for i in sorted(disease_id_to_name.keys())]
present_classes = sorted(list(set(y_test) | set(y_pred)))
present_class_names = [disease_id_to_name.get(i, f"Unknown ({i})") for i in present_classes]

report = classification_report(y_test, y_pred, target_names=present_class_names, output_dict=True)
report_df = pd.DataFrame(report).transpose()
print(report_df.round(4))

# Create a pandas DataFrame for easier reporting
metrics_df = pd.DataFrame({
    'Disease': [disease_id_to_name.get(i, f"Unknown ({i})") for i in present_classes],
    'Precision': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['precision'] for i in present_classes],
    'Recall': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['recall'] for i in present_classes],
    'F1-Score': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['f1-score'] for i in present_classes],
    'Support': [report[disease_id_to_name.get(i, f"Unknown ({i})")]['support'] for i in present_classes]
})

print("\nMetrics by Disease Class:")
print(metrics_df.round(4))

# Calculate overall weighted metrics
weighted_precision = precision_score(y_test, y_pred, average='weighted')
weighted_recall = recall_score(y_test, y_pred, average='weighted')
weighted_f1 = f1_score(y_test, y_pred, average='weighted')

print("\nOverall Weighted Metrics:")
print(f"Weighted Precision: {weighted_precision:.4f}")
print(f"Weighted Recall: {weighted_recall:.4f}")
print(f"Weighted F1-Score: {weighted_f1:.4f}")

# Create confusion matrix
print("\nGenerating confusion matrix visualization...")
cm = confusion_matrix(y_test, y_pred)
cm_display = ConfusionMatrixDisplay(
    confusion_matrix=cm, 
    display_labels=[disease_id_to_name.get(i, f"ID: {i}") for i in present_classes]
)

plt.figure(figsize=(10, 8))
cm_display.plot(cmap='Blues', xticks_rotation=45)
plt.title('Confusion Matrix for Poultry Disease Prediction')
plt.tight_layout()
plt.savefig('confusion_matrix.png')
print("Confusion matrix saved as 'confusion_matrix.png'")

# Generate a more detailed heatmap with percentages
plt.figure(figsize=(12, 10))
cm_percent = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis] * 100
sns.heatmap(cm_percent, annot=True, fmt='.1f', cmap='Blues',
            xticklabels=[disease_id_to_name.get(i, f"ID: {i}") for i in present_classes],
            yticklabels=[disease_id_to_name.get(i, f"ID: {i}") for i in present_classes])
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.title('Confusion Matrix (% of true class)')
plt.tight_layout()
plt.savefig('confusion_matrix_percent.png')
print("Percentage confusion matrix saved as 'confusion_matrix_percent.png'")

# Save detailed metrics to CSV for reference
metrics_df.to_csv('model_metrics_by_class.csv', index=False)
report_df.to_csv('model_classification_report.csv')
print("Detailed metrics saved to CSV files")

print("\nModel evaluation complete!")