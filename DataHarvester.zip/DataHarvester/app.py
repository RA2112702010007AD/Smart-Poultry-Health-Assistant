import streamlit as st
import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import os

# Set page config
st.set_page_config(
    page_title="Poultry Disease Prediction Dashboard",
    page_icon="🐔",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load the model and related data
@st.cache_resource
def load_model():
    try:
        with open('poultry_disease_prediction_model.pkl', 'rb') as f:
            model_data = pickle.load(f)
        return model_data
    except FileNotFoundError:
        st.error("Model file not found. Please train the model first using the Jupyter notebook.")
        return None

model_data = load_model()

if model_data:
    model = model_data['model']
    scaler = model_data['scaler']
    features = model_data['features']
    disease_id_to_name = model_data['disease_id_to_name']
    thresholds = model_data['thresholds']
else:
    # Default thresholds in case model is not loaded
    thresholds = {
        "co2": {"max": 3500, "critical": 5000},  # ppm
        "temperature": {"ideal": 27.5, "max": 31},  # Celsius
        "co": {"max": 800},  # Carbon Monoxide (ppm)
        "ammonia": {"max": 25},  # ppm
        "humidity": {"min": 50, "max": 60},  # percentage (RH)
        "water_hardness": {"max": 300},  # ppm
        "water_ph": {"ideal": 6.5}  # pH
    }

# Title and description
st.title('🐔 Poultry Disease Prediction System')

st.markdown("""
This dashboard allows you to predict potential poultry diseases based on environmental sensor data.
Upload your sensor data or use the manual input form to get predictions.
""")

# Sidebar for navigation
st.sidebar.title("📌 Navigation")

# Add a custom CSS style for the sidebar
st.sidebar.markdown("""
<style>
    .sidebar-nav {
        background-color: #f0f8ff;
        border-radius: 10px;
        padding: 10px;
        margin-bottom: 20px;
    }
    .nav-item {
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 5px;
        cursor: pointer;
    }
    .nav-item:hover {
        background-color: #e0f0ff;
    }
    .nav-selected {
        background-color: #4a86e8;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# Show system status
model_status = "✅ Model loaded successfully" if model_data else "❌ Model not loaded"

# Display status information
st.sidebar.markdown(f"**System Status:** {model_status}")
st.sidebar.markdown(f"**Notification Status:** ✅ Automatic notifications to jenniearul@gmail.com enabled")

# Create a more visual navigation menu
page_options = {
    "Dashboard": "📊",
    "Manual Prediction": "🔍",
    "Model Evaluation": "📈",
    "Settings": "⚙️",
    "About": "ℹ️"
}

# Display options with custom formatting
selected_page = None
st.sidebar.markdown('<div class="sidebar-nav">', unsafe_allow_html=True)
for page_name, icon in page_options.items():
    if st.sidebar.button(f"{icon} {page_name}", key=f"nav_{page_name}"):
        selected_page = page_name

st.sidebar.markdown('</div>', unsafe_allow_html=True)

# Default to Dashboard if nothing selected
if selected_page is None:
    if 'current_page' not in st.session_state:
        selected_page = "Dashboard"
        st.session_state.current_page = selected_page
    else:
        selected_page = st.session_state.current_page
else:
    st.session_state.current_page = selected_page

page = selected_page

# Function to predict disease and generate trigger
def predict_disease_and_generate_trigger(model, scaler, features, data):
    """
    Predict the disease based on environmental parameters and generate appropriate triggers.
    Also sends notification emails for high-risk disease predictions.
    
    Parameters:
    - model: Trained machine learning model
    - scaler: Fitted StandardScaler
    - features: List of feature names used in the model
    - data: DataFrame containing the environmental data
    
    Returns:
    - predictions: DataFrame with predicted diseases and trigger information
    """
    # Fill missing features not in the input data
    for feature in features:
        if feature not in data.columns:
            if feature.startswith('season_'):
                # Handle one-hot encoded season features
                season_name = feature.split('_', 1)[1]
                if 'season' in data.columns and data['season'].iloc[0] == season_name:
                    data[feature] = 1
                else:
                    data[feature] = 0
            elif feature.endswith('_rolling_avg_6h') and feature.split('_')[0] in data.columns:
                # Handle rolling averages
                base_col = feature.split('_')[0]
                data[feature] = data[base_col]
            elif feature.endswith('_rolling_std_6h') and feature.split('_')[0] in data.columns:
                # Handle rolling std
                data[feature] = 0.1  # Assume small standard deviation
            elif feature.endswith('_threshold') and 'above' in feature and feature.split('_')[0] in data.columns:
                # Handle threshold breach features
                param = feature.split('_')[0]
                if param == 'temp':
                    param = 'temperature'
                data[feature] = (data[param] > thresholds[param]['max']).astype(int)
            elif feature == 'THI' and 'temperature' in data.columns and 'humidity' in data.columns:
                # Calculate THI
                data[feature] = (0.8 * data['temperature'] + 0.01 * data['humidity'] * 
                              (data['temperature'] - 14.4) + 46.4)
            elif feature.startswith('daily_avg_') and feature.split('_')[-1] in data.columns:
                # Handle daily averages
                base_col = feature.split('_')[-1]
                data[feature] = data[base_col]
            else:
                # Default to 0 for missing features
                data[feature] = 0
    
    # Extract features from data
    X = data[features]
    
    # Scale the features
    X_scaled = scaler.transform(X)
    
    # Predict disease IDs
    predicted_disease_ids = model.predict(X_scaled)
    
    # Get disease names from IDs
    predicted_disease_names = [disease_id_to_name.get(id, f"Unknown ({id})") for id in predicted_disease_ids]
    
    # Generate probability scores for each disease
    disease_probabilities = model.predict_proba(X_scaled)
    
    # Create a DataFrame for predictions
    columns_to_keep = ['temperature', 'humidity', 'co2', 'ammonia', 'bird_age', 'season']
    columns_available = [col for col in columns_to_keep if col in data.columns]
    
    predictions = data[columns_available].copy()
    predictions['predicted_disease_id'] = predicted_disease_ids
    predictions['predicted_disease'] = predicted_disease_names
    predictions['confidence'] = np.max(disease_probabilities, axis=1)
    
    # Generate triggers based on thresholds and predicted diseases
    # Threshold breaches
    temp_breach = predictions['temperature'] > thresholds['temperature']['max'] if 'temperature' in predictions.columns else False
    co2_breach = predictions['co2'] > thresholds['co2']['max'] if 'co2' in predictions.columns else False
    ammonia_breach = predictions['ammonia'] > thresholds['ammonia']['max'] if 'ammonia' in predictions.columns else False
    humidity_low = predictions['humidity'] < thresholds['humidity']['min'] if 'humidity' in predictions.columns else False
    humidity_high = predictions['humidity'] > thresholds['humidity']['max'] if 'humidity' in predictions.columns else False
    
    # Initialize trigger messages
    triggers = []
    alert_levels = []
    
    for idx, row in predictions.iterrows():
        trigger_msgs = []
        disease_confidence = row['confidence']
        
        # Alert level calculation
        alert_level = 0  # 0: Normal, 1: Warning, 2: Alert, 3: Critical
        
        # Check environment thresholds
        if 'temperature' in row and temp_breach[idx]:
            trigger_msgs.append(f"Temperature above threshold: {row['temperature']:.1f}°C > {thresholds['temperature']['max']}°C")
            alert_level = max(alert_level, 1)
        
        if 'co2' in row and co2_breach[idx]:
            trigger_msgs.append(f"CO2 level above threshold: {row['co2']:.0f} ppm > {thresholds['co2']['max']} ppm")
            alert_level = max(alert_level, 1)
        
        if 'ammonia' in row and ammonia_breach[idx]:
            trigger_msgs.append(f"Ammonia level above threshold: {row['ammonia']:.1f} ppm > {thresholds['ammonia']['max']} ppm")
            alert_level = max(alert_level, 2)
        
        if 'humidity' in row:
            if humidity_low[idx]:
                trigger_msgs.append(f"Humidity below minimum: {row['humidity']:.1f}% < {thresholds['humidity']['min']}%")
                alert_level = max(alert_level, 1)
            
            if humidity_high[idx]:
                trigger_msgs.append(f"Humidity above maximum: {row['humidity']:.1f}% > {thresholds['humidity']['max']}%")
                alert_level = max(alert_level, 1)
            
        # Disease prediction based triggers
        disease = row['predicted_disease']
        
        if disease != "Healthy" and disease_confidence > 0.7:
            if disease_confidence > 0.9:
                trigger_msgs.append(f"High risk of {disease} (confidence: {disease_confidence:.2f})")
                alert_level = max(alert_level, 3)
            elif disease_confidence > 0.8:
                trigger_msgs.append(f"Moderate risk of {disease} (confidence: {disease_confidence:.2f})")
                alert_level = max(alert_level, 2)
            else:
                trigger_msgs.append(f"Possible risk of {disease} (confidence: {disease_confidence:.2f})")
                alert_level = max(alert_level, 1)
        
        # Disease-specific recommendations
        if disease == "Pneumonia/Fungal" and disease_confidence > 0.7:
            trigger_msgs.append("Recommendation: Apply antifungal drugs in water and improve hatchery hygiene")
        elif disease == "Omphilitispis" and disease_confidence > 0.7:
            trigger_msgs.append("Recommendation: Maintain proper brooding hygiene and temperature")
        elif disease == "CRD" and disease_confidence > 0.7:
            trigger_msgs.append("Recommendation: Reduce ammonia levels and increase ventilation")
        elif disease == "Heat Stroke" and disease_confidence > 0.7:
            trigger_msgs.append("Recommendation: Increase ventilation and provide cooled water")
        
        # Combine all trigger messages
        if trigger_msgs:
            triggers.append(" | ".join(trigger_msgs))
        else:
            triggers.append("No triggers")
        
        alert_levels.append(alert_level)
    
    # Add triggers to predictions DataFrame
    predictions['triggers'] = triggers
    predictions['alert_level'] = alert_levels
    
    # Send email notifications for diseases detected with high confidence
    for idx, row in predictions.iterrows():
        disease = row['predicted_disease']
        confidence = row['confidence']
        
        # Check if we should send a notification
        notification_threshold = 0.7  # Default threshold
        # Override with user settings if available
        if 'email_settings' in st.session_state:
            notification_threshold = st.session_state.email_settings.get('notification_threshold', 0.7)
            enable_notifications = st.session_state.email_settings.get('enable_notifications', True)
        else:
            enable_notifications = True
        
        # Only send notifications for diseases that are not "Healthy" and have high confidence
        if (disease != "Healthy" and 
            confidence >= notification_threshold and 
            enable_notifications and 
            row['alert_level'] >= 2):  # Only for alert level 2 (Alert) or 3 (Critical)
            
            # Create a dictionary of environmental data
            env_data = {
                'temperature': row.get('temperature', 'N/A'),
                'humidity': row.get('humidity', 'N/A'),
                'co2': row.get('co2', 'N/A'),
                'ammonia': row.get('ammonia', 'N/A'),
                'bird_age': row.get('bird_age', 'N/A'),
                'season': row.get('season', 'N/A'),
                'timestamp': row.get('timestamp', datetime.now()).strftime('%Y-%m-%d %H:%M:%S') 
                             if hasattr(row.get('timestamp', datetime.now()), 'strftime') 
                             else datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Send the notification
            notification_sent = send_disease_notification(
                disease_name=disease,
                confidence=confidence,
                environmental_data=env_data,
                triggers=row['triggers']
            )
            
            # Log the notification attempt
            if notification_sent:
                print(f"Email notification sent for {disease} (confidence: {confidence:.2f})")
            else:
                print(f"Failed to send email notification for {disease}")
    
    return predictions

# Function to generate sample data for demonstration
def generate_sample_data(n_samples=24, current_season="summer"):
    """Generate sample sensor data for demonstration"""
    timestamps = [datetime.now() - timedelta(hours=i) for i in range(n_samples)]
    timestamps.reverse()  # So they go from past to present
    
    if current_season == "summer":
        temp_base, temp_var = 32, 3
        humidity_base, humidity_var = 55, 10
    elif current_season == "winter":
        temp_base, temp_var = 24, 4
        humidity_base, humidity_var = 70, 15
    elif current_season == "rainy":
        temp_base, temp_var = 28, 2
        humidity_base, humidity_var = 80, 10
    else:  # spring
        temp_base, temp_var = 26, 3
        humidity_base, humidity_var = 65, 10
    
    # Generate sensor values with some randomness and time patterns
    temperatures = [temp_base + temp_var * np.sin(i/12 * np.pi) + np.random.normal(0, 1) for i in range(n_samples)]
    humidities = [min(95, max(30, humidity_base + humidity_var * np.cos(i/12 * np.pi) + np.random.normal(0, 3))) for i in range(n_samples)]
    co2_levels = [2500 + 500 * np.sin(i/8 * np.pi) + np.random.normal(0, 200) for i in range(n_samples)]
    ammonia_levels = [15 + 10 * np.sin(i/10 * np.pi) + np.random.normal(0, 2) for i in range(n_samples)]
    
    # Ensure some values exceed thresholds
    if np.random.random() < 0.4:  # 40% chance of at least one threshold breach
        idx = np.random.randint(n_samples-5, n_samples)  # Near the end
        temperatures[idx] = thresholds['temperature']['max'] + np.random.uniform(1, 5)
        ammonia_levels[idx] = thresholds['ammonia']['max'] + np.random.uniform(5, 15)
    
    bird_age = 14  # Example age in days
    
    df = pd.DataFrame({
        'timestamp': timestamps,
        'temperature': temperatures,
        'humidity': humidities,
        'co2': co2_levels,
        'ammonia': ammonia_levels,
        'bird_age': [bird_age] * n_samples,
        'season': [current_season] * n_samples
    })
    
    # Convert season to one-hot encoding
    for season in ['summer', 'winter', 'rainy', 'spring']:
        df[f'season_{season}'] = (df['season'] == season).astype(int)
    
    return df

# Function to create plots
def create_plots(data):
    """Create plots for the dashboard"""
    # Create a figure with subplots
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Temperature plot
    sns.lineplot(x='timestamp', y='temperature', data=data, ax=axes[0, 0], marker='o')
    axes[0, 0].axhline(y=thresholds['temperature']['max'], color='r', linestyle='--', alpha=0.7, label=f"Threshold ({thresholds['temperature']['max']}°C)")
    axes[0, 0].set_title('Temperature Over Time')
    axes[0, 0].set_ylabel('Temperature (°C)')
    axes[0, 0].legend()
    
    # Humidity plot
    sns.lineplot(x='timestamp', y='humidity', data=data, ax=axes[0, 1], marker='o')
    axes[0, 1].axhline(y=thresholds['humidity']['min'], color='r', linestyle='--', alpha=0.7, label=f"Min Threshold ({thresholds['humidity']['min']}%)")
    axes[0, 1].axhline(y=thresholds['humidity']['max'], color='orange', linestyle='--', alpha=0.7, label=f"Max Threshold ({thresholds['humidity']['max']}%)")
    axes[0, 1].set_title('Humidity Over Time')
    axes[0, 1].set_ylabel('Humidity (%)')
    axes[0, 1].legend()
    
    # CO2 plot
    sns.lineplot(x='timestamp', y='co2', data=data, ax=axes[1, 0], marker='o')
    axes[1, 0].axhline(y=thresholds['co2']['max'], color='r', linestyle='--', alpha=0.7, label=f"Threshold ({thresholds['co2']['max']} ppm)")
    axes[1, 0].set_title('CO2 Levels Over Time')
    axes[1, 0].set_ylabel('CO2 (ppm)')
    axes[1, 0].legend()
    
    # Ammonia plot
    sns.lineplot(x='timestamp', y='ammonia', data=data, ax=axes[1, 1], marker='o')
    axes[1, 1].axhline(y=thresholds['ammonia']['max'], color='r', linestyle='--', alpha=0.7, label=f"Threshold ({thresholds['ammonia']['max']} ppm)")
    axes[1, 1].set_title('Ammonia Levels Over Time')
    axes[1, 1].set_ylabel('Ammonia (ppm)')
    axes[1, 1].legend()
    
    # Format timestamp labels
    for ax in axes.flat:
        ax.set_xlabel('Time')
        ax.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    return fig

def plot_disease_confidence(predictions):
    """Plot disease confidence over time"""
    # Group by disease and plot confidence
    disease_confidence = predictions.groupby('predicted_disease')['confidence'].mean().sort_values(ascending=False)
    
    fig, ax = plt.subplots(figsize=(10, 5))
    disease_confidence.plot(kind='bar', ax=ax, color=sns.color_palette("viridis", len(disease_confidence)))
    
    ax.set_title('Disease Prediction Confidence')
    ax.set_ylabel('Confidence')
    ax.set_xlabel('Predicted Disease')
    ax.set_ylim(0, 1.0)
    
    # Add confidence values above bars
    for i, v in enumerate(disease_confidence):
        ax.text(i, v + 0.03, f"{v:.2f}", ha='center')
    
    plt.tight_layout()
    return fig

def render_dashboard():
    """Render the main dashboard"""
    st.header("🖥️ Real-time Monitoring Dashboard")
    
    # Add a container for the generate data button with styling
    gen_data_container = st.container()
    with gen_data_container:
        col1, col2 = st.columns([1, 3])
        with col1:
            if st.button("🔄 Generate Sample Data", key="gen_data_btn"):
                with st.spinner("Generating sample data..."):
                    st.session_state.sample_data = generate_sample_data(
                        n_samples=24, 
                        current_season=st.session_state.get('season', 'summer')
                    )
                    st.success("Sample data generated!")
        
        with col2:
            st.markdown("""
            <div style="background-color: #f0f8ff; padding: 10px; border-radius: 5px; margin-top: 10px;">
                <p style="margin-bottom: 0">💡 <b>Tip:</b> Click the button to generate random sensor data based on the selected season. 
                The system will analyze this data to predict potential poultry diseases.</p>
            </div>
            """, unsafe_allow_html=True)
    
    # Season selector in sidebar with visual indicators
    st.sidebar.markdown("## 🌡️ Simulation Settings")
    
    # Add season icons
    season_icons = {
        "summer": "☀️ Summer (Hot)",
        "winter": "❄️ Winter (Cold)",
        "rainy": "🌧️ Rainy (Humid)",
        "spring": "🌱 Spring (Mild)"
    }
    
    season_list = list(season_icons.keys())
    season_display = list(season_icons.values())
    
    current_season_index = season_list.index(st.session_state.get('season', 'summer'))
    season = st.sidebar.selectbox(
        "Select Season", 
        season_display,
        index=current_season_index
    )
    # Extract actual season from the display string
    selected_season = season_list[season_display.index(season)]
    st.session_state.season = selected_season
    
    # Add a slider for sample size
    if 'sample_size' not in st.session_state:
        st.session_state.sample_size = 24
    
    sample_size = st.sidebar.slider("Sample Hours", min_value=6, max_value=48, value=st.session_state.sample_size, step=6)
    st.session_state.sample_size = sample_size
    
    # Show sample data if available
    if 'sample_data' in st.session_state:
        sample_data = st.session_state.sample_data
        
        # Make predictions
        if model_data:
            predictions = predict_disease_and_generate_trigger(model, scaler, features, sample_data)
            
            # Create tabs for different sections of the dashboard
            tab1, tab2, tab3 = st.tabs(["📊 Current Readings", "📈 Environmental Trends", "⚠️ Disease Predictions"])
            
            with tab1:
                st.subheader("Latest Sensor Readings")
                
                # Dashboard metrics with dynamic colors
                col1, col2, col3, col4 = st.columns(4)
                
                # Latest readings with color indicators
                latest = sample_data.iloc[-1]
                prev = sample_data.iloc[-2] if len(sample_data) > 1 else latest
                
                # Temperature with colored background based on threshold
                temp = latest['temperature']
                temp_diff = temp - prev['temperature']
                temp_status = "🔴" if temp > thresholds['temperature']['max'] else "🟢"
                col1.markdown(f"""
                <div style="background-color: {'#ffeded' if temp > thresholds['temperature']['max'] else '#f0f0f0'}; 
                            padding: 10px; 
                            border-radius: 5px; 
                            text-align: center;">
                    <h3 style="margin: 0">{temp_status} Temperature</h3>
                    <p style="font-size: 24px; margin: 5px 0">{temp:.1f}°C</p>
                    <p style="margin: 0">Change: {temp_diff:.1f}°C</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Humidity with colored background
                humidity = latest['humidity']
                humidity_diff = humidity - prev['humidity']
                humidity_status = "🔴" if (humidity < thresholds['humidity']['min'] or humidity > thresholds['humidity']['max']) else "🟢"
                col2.markdown(f"""
                <div style="background-color: {'#ffeded' if (humidity < thresholds['humidity']['min'] or humidity > thresholds['humidity']['max']) else '#f0f0f0'}; 
                            padding: 10px; 
                            border-radius: 5px; 
                            text-align: center;">
                    <h3 style="margin: 0">{humidity_status} Humidity</h3>
                    <p style="font-size: 24px; margin: 5px 0">{humidity:.1f}%</p>
                    <p style="margin: 0">Change: {humidity_diff:.1f}%</p>
                </div>
                """, unsafe_allow_html=True)
                
                # CO2 with colored background
                co2 = latest['co2']
                co2_diff = co2 - prev['co2']
                co2_status = "🔴" if co2 > thresholds['co2']['max'] else "🟢"
                col3.markdown(f"""
                <div style="background-color: {'#ffeded' if co2 > thresholds['co2']['max'] else '#f0f0f0'}; 
                            padding: 10px; 
                            border-radius: 5px; 
                            text-align: center;">
                    <h3 style="margin: 0">{co2_status} CO2 Level</h3>
                    <p style="font-size: 24px; margin: 5px 0">{co2:.0f} ppm</p>
                    <p style="margin: 0">Change: {co2_diff:.0f} ppm</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Ammonia with colored background
                ammonia = latest['ammonia']
                ammonia_diff = ammonia - prev['ammonia']
                ammonia_status = "🔴" if ammonia > thresholds['ammonia']['max'] else "🟢"
                col4.markdown(f"""
                <div style="background-color: {'#ffeded' if ammonia > thresholds['ammonia']['max'] else '#f0f0f0'}; 
                            padding: 10px; 
                            border-radius: 5px; 
                            text-align: center;">
                    <h3 style="margin: 0">{ammonia_status} Ammonia</h3>
                    <p style="font-size: 24px; margin: 5px 0">{ammonia:.1f} ppm</p>
                    <p style="margin: 0">Change: {ammonia_diff:.1f} ppm</p>
                </div>
                """, unsafe_allow_html=True)
            
            with tab2:
                st.subheader("Environmental Parameter Trends")
                # Plot environmental data
                st.pyplot(create_plots(sample_data))
                
                # Add interactive data table with expandable view
                if st.checkbox("Show Raw Sensor Data", key="show_raw"):
                    with st.expander("Raw Data Table", expanded=True):
                        st.dataframe(sample_data[['timestamp', 'temperature', 'humidity', 'co2', 'ammonia']])
            
            with tab3:
                st.subheader("Disease Prediction Analysis")
                
                # Plot disease confidence
                st.pyplot(plot_disease_confidence(predictions))
                
                # Create a dataframe with the most recent predictions
                recent_predictions = predictions.tail(5).copy()
                
                # Format the alert levels with colors
                def alert_color(alert_level):
                    if alert_level == 0:
                        return "normal"
                    elif alert_level == 1:
                        return "warning"
                    elif alert_level == 2:
                        return "alert"
                    else:
                        return "critical"
                
                recent_predictions['alert_status'] = recent_predictions['alert_level'].apply(alert_color)
            
            # Display recent predictions with styling
            st.dataframe(
                recent_predictions[['predicted_disease', 'confidence', 'alert_status', 'triggers']],
                column_config={
                    "alert_status": st.column_config.SelectboxColumn(
                        "Alert Level",
                        options=["normal", "warning", "alert", "critical"],
                        required=True,
                    ),
                    "confidence": st.column_config.ProgressColumn(
                        "Confidence",
                        format="%.2f",
                        min_value=0,
                        max_value=1,
                    ),
                },
                hide_index=True,
            )
            
            # Display any critical alerts
            critical_alerts = predictions[predictions['alert_level'] >= 2]
            if not critical_alerts.empty:
                st.error("⚠️ Critical Alerts Detected!")
                for _, alert in critical_alerts.iterrows():
                    st.warning(f"**{alert['predicted_disease']}** - {alert['triggers']}")
        else:
            st.error("Model not loaded. Please train the model first.")
    else:
        st.info("Click 'Generate Sample Data' to simulate environmental sensor readings and disease predictions.")

def render_manual_prediction():
    """Render the manual prediction page"""
    st.header("🔍 Manual Disease Prediction")
    
    st.markdown("""
    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
        <h3 style="margin-top: 0">📝 Input Environmental Parameters</h3>
        <p>Enter the current environmental conditions and bird information to predict potential diseases.
        The model will analyze these values to assess disease risk.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create two columns for the form and reference values
    form_col, ref_col = st.columns([3, 1])
    
    with form_col:
        # Manual input form with styled container
        with st.form("prediction_form"):
            st.markdown('<p style="text-align: center; font-weight: bold; font-size: 18px;">Sensor Parameters</p>', 
                        unsafe_allow_html=True)
            
            # Add divider and layout
            col1, col2 = st.columns(2)
            
            with col1:
                # Temperature with hint about normal range
                temp_default = 28.0
                temperature = st.number_input(
                    "Temperature (°C)", 
                    min_value=15.0, 
                    max_value=45.0, 
                    value=temp_default, 
                    step=0.1,
                    help=f"Ideal range: 26-{thresholds['temperature']['max']}°C"
                )
                
                # Visual slider for temperature range
                st.markdown(f"""
                <div style="margin-bottom: 25px; padding: 5px;">
                    <div style="height: 5px; background: linear-gradient(to right, blue, green, yellow, orange, red); 
                              border-radius: 5px; margin-bottom: 2px;">
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 12px;">
                        <span>Cold (15°C)</span>
                        <span>Ideal (27.5°C)</span>
                        <span>Hot (45°C)</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Humidity with note
                humidity = st.number_input(
                    "Humidity (%)", 
                    min_value=30.0, 
                    max_value=95.0, 
                    value=55.0, 
                    step=0.1,
                    help=f"Ideal range: {thresholds['humidity']['min']}-{thresholds['humidity']['max']}%"
                )
            
            with col2:
                co2 = st.number_input(
                    "CO2 Level (ppm)", 
                    min_value=400, 
                    max_value=6000, 
                    value=2500, 
                    step=100,
                    help=f"Maximum safe level: {thresholds['co2']['max']} ppm"
                )
                
                ammonia = st.number_input(
                    "Ammonia Level (ppm)", 
                    min_value=0.0, 
                    max_value=50.0, 
                    value=15.0, 
                    step=0.1,
                    help=f"Maximum safe level: {thresholds['ammonia']['max']} ppm"
                )
            
            st.markdown('<p style="text-align: center; font-weight: bold; font-size: 18px; margin-top: 10px;">Flock Information</p>', 
                        unsafe_allow_html=True)
            
            col3, col4 = st.columns(2)
            
            with col3:
                bird_age = st.number_input(
                    "Bird Age (days)", 
                    min_value=1, 
                    max_value=42, 
                    value=14, 
                    step=1,
                    help="Age of birds in days (1-42 day cycle)"
                )
            
            with col4:
                # Use the same season icons as in the dashboard
                season_icons = {
                    "summer": "☀️ Summer (Hot)",
                    "winter": "❄️ Winter (Cold)",
                    "rainy": "🌧️ Rainy (Humid)",
                    "spring": "🌱 Spring (Mild)"
                }
                season_display = list(season_icons.values())
                selected_season_display = st.selectbox("Season", season_display)
                # Extract the actual season value
                season = next(key for key, value in season_icons.items() if value == selected_season_display)
            
            submitted = st.form_submit_button("🔎 Predict Disease", 
                                            help="Click to analyze the parameters and predict disease risk")
    
    with ref_col:
        # Reference information sidebar
        st.markdown("""
        ### 📊 Reference Values
        
        **Temperature:**
        - Ideal: 26-28°C
        - Max: 31°C
        
        **Humidity:**
        - Min: 50%
        - Max: 60%
        
        **CO2 Level:**
        - Normal: <2,500 ppm
        - Max: 3,500 ppm
        
        **Ammonia Level:**
        - Normal: <15 ppm
        - Max: 25 ppm
        """)
    
    if submitted:
        if model_data:
            # Create a DataFrame with the input values
            input_data = pd.DataFrame({
                'timestamp': [datetime.now()],
                'temperature': [temperature],
                'humidity': [humidity],
                'co2': [co2],
                'ammonia': [ammonia],
                'bird_age': [bird_age],
                'season': [season]
            })
            
            # Convert season to one-hot encoding
            for s in ['summer', 'winter', 'rainy', 'spring']:
                input_data[f'season_{s}'] = (input_data['season'] == s).astype(int)
            
            # Make prediction
            prediction = predict_disease_and_generate_trigger(model, scaler, features, input_data)
            
            # Display the results
            st.subheader("Prediction Results")
            
            # Show the predicted disease with confidence
            disease = prediction['predicted_disease'].iloc[0]
            confidence = prediction['confidence'].iloc[0]
            
            # Use different colors based on disease (Healthy vs Disease)
            if disease == "Healthy":
                st.success(f"**Predicted Status: {disease}** (Confidence: {confidence:.2f})")
            else:
                st.error(f"**Predicted Disease: {disease}** (Confidence: {confidence:.2f})")
            
            # Show the triggers
            st.subheader("Triggers and Recommendations")
            triggers = prediction['triggers'].iloc[0]
            
            if triggers == "No triggers":
                st.info("No triggers or recommendations at this time.")
            else:
                for trigger in triggers.split(" | "):
                    if "Recommendation:" in trigger:
                        st.info(trigger)
                    elif "High risk" in trigger or "above threshold" in trigger:
                        st.error(trigger)
                    elif "Moderate risk" in trigger:
                        st.warning(trigger)
                    else:
                        st.info(trigger)
            
            # Display thresholds for reference
            st.subheader("Reference Thresholds")
            threshold_data = {
                "Parameter": ["Temperature", "Humidity (Min)", "Humidity (Max)", "CO2", "Ammonia"],
                "Threshold": [
                    f"{thresholds['temperature']['max']}°C",
                    f"{thresholds['humidity']['min']}%",
                    f"{thresholds['humidity']['max']}%",
                    f"{thresholds['co2']['max']} ppm",
                    f"{thresholds['ammonia']['max']} ppm"
                ]
            }
            st.table(pd.DataFrame(threshold_data))
            
            # Show parameter status (within range or out of range)
            st.subheader("Parameter Status")
            
            param_status = {
                "Parameter": ["Temperature", "Humidity", "CO2", "Ammonia"],
                "Current Value": [
                    f"{temperature:.1f}°C",
                    f"{humidity:.1f}%",
                    f"{co2:.0f} ppm",
                    f"{ammonia:.1f} ppm"
                ],
                "Status": [
                    "❌ Above Threshold" if temperature > thresholds['temperature']['max'] else "✅ Within Range",
                    "❌ Outside Range" if (humidity < thresholds['humidity']['min'] or humidity > thresholds['humidity']['max']) else "✅ Within Range",
                    "❌ Above Threshold" if co2 > thresholds['co2']['max'] else "✅ Within Range",
                    "❌ Above Threshold" if ammonia > thresholds['ammonia']['max'] else "✅ Within Range"
                ]
            }
            
            status_df = pd.DataFrame(param_status)
            st.dataframe(status_df, hide_index=True)
            
        else:
            st.error("Model not loaded. Please train the model first.")

def render_about():
    """Render the about page"""
    st.header("ℹ️ About This System")
    
    # Create tabs for different sections of the about page
    about_tab1, about_tab2, about_tab3, about_tab4 = st.tabs([
        "🔍 Overview", 
        "🦠 Diseases", 
        "🌡️ Parameters", 
        "💻 Technical Info"
    ])
    
    with about_tab1:
        # Overview tab with colorful cards
        st.markdown("""
        <div style="background-color: #f0f8ff; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
            <h2 style="margin-top: 0; color: #0066cc;">🐔 Poultry Disease Prediction System</h2>
            <p>This intelligent system uses machine learning to predict potential poultry diseases 
            based on environmental sensor data. It monitors key parameters like temperature, humidity, 
            CO2, and ammonia levels to provide early warnings for disease outbreaks.</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Key features in a visual layout
        st.subheader("Key Features")
        
        # Create 2x3 grid for features
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">📊 Real-time Monitoring</h4>
                <p style="margin-bottom: 0;">Track environmental conditions in real-time with visual alerts</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">🚨 Early Warning System</h4>
                <p style="margin-bottom: 0;">Generate alerts when conditions become favorable for diseases</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">🐣 Age-specific Predictions</h4>
                <p style="margin-bottom: 0;">Consider bird age for more accurate predictions</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">🔬 Disease Prediction</h4>
                <p style="margin-bottom: 0;">Predict potential diseases before they manifest with high confidence</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">🌦️ Seasonal Analysis</h4>
                <p style="margin-bottom: 0;">Account for seasonal variations in disease patterns</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                <h4 style="margin-top: 0;">📱 User-friendly Interface</h4>
                <p style="margin-bottom: 0;">Interactive dashboard with clear visualizations and recommendations</p>
            </div>
            """, unsafe_allow_html=True)
        
        # How to use section
        st.subheader("How to Use")
        
        st.markdown("""
        <div style="display: flex; margin-bottom: 20px;">
            <div style="background-color: #0066cc; color: white; border-radius: 50%; width: 30px; height: 30px; 
                        display: flex; justify-content: center; align-items: center; margin-right: 10px;">1</div>
            <div style="flex-grow: 1;">
                <p style="margin: 0;"><strong>Generate sample data</strong> or use the manual input form</p>
            </div>
        </div>
        
        <div style="display: flex; margin-bottom: 20px;">
            <div style="background-color: #0066cc; color: white; border-radius: 50%; width: 30px; height: 30px; 
                        display: flex; justify-content: center; align-items: center; margin-right: 10px;">2</div>
            <div style="flex-grow: 1;">
                <p style="margin: 0;"><strong>Review the predicted diseases</strong> and confidence levels</p>
            </div>
        </div>
        
        <div style="display: flex; margin-bottom: 20px;">
            <div style="background-color: #0066cc; color: white; border-radius: 50%; width: 30px; height: 30px; 
                        display: flex; justify-content: center; align-items: center; margin-right: 10px;">3</div>
            <div style="flex-grow: 1;">
                <p style="margin: 0;"><strong>Check the recommended actions</strong> to prevent disease outbreaks</p>
            </div>
        </div>
        
        <div style="display: flex; margin-bottom: 20px;">
            <div style="background-color: #0066cc; color: white; border-radius: 50%; width: 30px; height: 30px; 
                        display: flex; justify-content: center; align-items: center; margin-right: 10px;">4</div>
            <div style="flex-grow: 1;">
                <p style="margin: 0;"><strong>Monitor environmental parameters</strong> regularly for optimal conditions</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with about_tab2:
        # Diseases tab with categorized disease information
        st.subheader("Monitored Poultry Diseases")
        
        st.markdown("""
        The system can predict up to 14 different poultry diseases based on environmental patterns, 
        bird age, and seasonal variations. These are categorized by their primary cause:
        """)
        
        # Create expandable sections for disease categories
        with st.expander("Bacterial Diseases", expanded=True):
            st.markdown("""
            - **CRD (Chronic Respiratory Disease)** - Affects birds 18-35 days old, common in summer
            - **Omphilitispis (Naval infection)** - Affects birds 1-8 days old, seen in all seasons
            - **Colli Basilocious** - Affects birds 1-7 days old, common in all seasons
            """)
        
        with st.expander("Viral Diseases", expanded=False):
            st.markdown("""
            - **IBD (Infectious Bursal Disease)** - Affects birds 9-12 days old, common in rainy and winter seasons
            - **Avian Influenza (Bird Flu)** - Affects birds of all ages, common in summer and winter
            - **New Castle Disease** - Affects birds of all ages, common in all seasons especially summer
            - **Infectious Bronchitis** - Affects birds 7-40 days old, common in all seasons
            """)
        
        with st.expander("Fungal Diseases", expanded=False):
            st.markdown("""
            - **Pneumonia/Fungal infections** - Affects birds 1-7 days old, more common in rainy and winter seasons
            """)
        
        with st.expander("Environmental/Metabolic Conditions", expanded=False):
            st.markdown("""
            - **Heat Stroke** - Affects birds of all ages, common in summer with high temperatures
            - **Hurdlling** - Affects birds 1-2 days old, common in winter
            - **Asscites** - Affects birds 7-40 days old, common in winter with high CO2/ammonia levels
            - **Gout** - Affects birds 6-12 days old, common in rainy and winter seasons
            """)
        
        with st.expander("Other Diseases", expanded=False):
            st.markdown("""
            - **Cacoccidiosis** - Protozoal disease affecting birds 14-18 days old, common in rainy season
            - **Tortticollies** - Neural syndrome affecting birds 5-30 days old, common in all seasons
            """)
        
        # Disease impact visualization
        st.subheader("Primary Environmental Factors")
        
        # Create a visual representation of disease triggers
        st.markdown("""
        <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 20px;">
            <div style="flex: 1; min-width: 200px; background-color: #ffeded; padding: 15px; border-radius: 10px;">
                <h4 style="margin-top: 0;">🌡️ High Temperature</h4>
                <p>Primary factor for Heat Stroke, Avian Influenza, and Infectious Bronchitis</p>
            </div>
            
            <div style="flex: 1; min-width: 200px; background-color: #eaf7ea; padding: 15px; border-radius: 10px;">
                <h4 style="margin-top: 0;">💧 High Humidity</h4>
                <p>Primary factor for Pneumonia/Fungal infections and Cacoccidiosis</p>
            </div>
            
            <div style="flex: 1; min-width: 200px; background-color: #e6f2ff; padding: 15px; border-radius: 10px;">
                <h4 style="margin-top: 0;">☁️ High CO2</h4>
                <p>Primary factor for Asscites and CRD</p>
            </div>
            
            <div style="flex: 1; min-width: 200px; background-color: #fff3e0; padding: 15px; border-radius: 10px;">
                <h4 style="margin-top: 0;">🧪 High Ammonia</h4>
                <p>Primary factor for CRD, New Castle, and Avian Influenza</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with about_tab3:
        # Parameters tab with information about environmental parameters
        st.subheader("Environmental Parameters & Thresholds")
        
        # Create parameter cards
        col1, col2 = st.columns(2)
        
        with col1:
            # Temperature card
            st.markdown("""
            <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e4e7eb 100%); 
                        padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h3 style="margin-top: 0;">🌡️ Temperature</h3>
                <p><strong>Ideal Range:</strong> 26-28°C</p>
                <p><strong>Maximum:</strong> 31°C</p>
                <p><strong>Impact:</strong> Higher temperatures increase risk of heat stroke and respiratory diseases</p>
                <div style="height: 6px; background: linear-gradient(to right, blue, green, yellow, red); 
                          border-radius: 3px; margin: 10px 0;">
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px;">
                    <span>15°C (Cold)</span>
                    <span>27.5°C (Ideal)</span>
                    <span>45°C (Hot)</span>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # CO2 card
            st.markdown("""
            <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e4e7eb 100%); 
                        padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h3 style="margin-top: 0;">☁️ CO2 Level</h3>
                <p><strong>Normal Range:</strong> 1000-2500 ppm</p>
                <p><strong>Maximum:</strong> 3500 ppm</p>
                <p><strong>Critical:</strong> 5000+ ppm</p>
                <p><strong>Impact:</strong> High CO2 indicates poor ventilation and increases respiratory disease risk</p>
                <div style="height: 6px; background: linear-gradient(to right, green, yellow, orange, red); 
                          border-radius: 3px; margin: 10px 0;">
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px;">
                    <span>400 ppm (Fresh air)</span>
                    <span>3500 ppm (Max)</span>
                    <span>6000 ppm (Critical)</span>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            # Humidity card
            st.markdown("""
            <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e4e7eb 100%); 
                        padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h3 style="margin-top: 0;">💧 Humidity</h3>
                <p><strong>Ideal Range:</strong> 50-60%</p>
                <p><strong>Minimum:</strong> 50%</p>
                <p><strong>Maximum:</strong> 60%</p>
                <p><strong>Impact:</strong> Low humidity causes dehydration; high humidity promotes fungal diseases</p>
                <div style="height: 6px; background: linear-gradient(to right, orange, green, orange); 
                          border-radius: 3px; margin: 10px 0;">
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px;">
                    <span>30% (Too dry)</span>
                    <span>55% (Ideal)</span>
                    <span>95% (Too humid)</span>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Ammonia card
            st.markdown("""
            <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e4e7eb 100%); 
                        padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                <h3 style="margin-top: 0;">🧪 Ammonia</h3>
                <p><strong>Normal Range:</strong> 5-15 ppm</p>
                <p><strong>Maximum:</strong> 25 ppm</p>
                <p><strong>Impact:</strong> High ammonia damages respiratory system and reduces feed consumption</p>
                <div style="height: 6px; background: linear-gradient(to right, green, yellow, red); 
                          border-radius: 3px; margin: 10px 0;">
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px;">
                    <span>0 ppm (None)</span>
                    <span>25 ppm (Max)</span>
                    <span>50 ppm (Toxic)</span>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Additional parameters
        st.markdown("""
        ### Additional Parameters
        
        - **Carbon Monoxide (CO)**: Should be less than 800 ppm
        - **Water Quality**:
            - Hardness should be below 300 ppm
            - pH should be around 6.5 for optimal health
            
        ### Seasonal Considerations
        
        Different seasons bring unique challenges for poultry health:
        
        - **Summer**: High risk of heat stress and dehydration
        - **Winter**: Ventilation challenges and respiratory diseases
        - **Rainy Season**: Increased risk of fungal and bacterial diseases
        - **Spring**: Generally moderate conditions, but still requires monitoring
        """)
    
    with about_tab4:
        # Technical info tab
        st.subheader("Technical Information")
        
        # Model information
        st.markdown("""
        <div style="background-color: #f0f8ff; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
            <h3 style="margin-top: 0;">🤖 Machine Learning Model</h3>
            <p>This system uses a Random Forest classifier trained on environmental sensor data 
            and disease patterns. The model achieves approximately 79% accuracy in predicting 
            potential diseases.</p>
            <p>The model analyzes multiple factors including:</p>
            <ul>
                <li>Current environmental readings (temperature, humidity, CO2, ammonia)</li>
                <li>Historical patterns and rolling averages</li>
                <li>Bird age and developmental stage</li>
                <li>Seasonal considerations</li>
                <li>Threshold breaches and environmental stability</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        
        # Technologies used
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            ### 🛠️ Technologies
            
            The system is built with:
            
            - **Python** - Core programming language
            - **Streamlit** - Web interface and visualization
            - **Scikit-learn** - Machine learning framework
            - **Pandas** - Data processing and manipulation
            - **Matplotlib/Seaborn** - Data visualization
            - **NumPy** - Numerical computing
            """)
        
        with col2:
            st.markdown("""
            ### 📊 Data Pipeline
            
            The system follows this processing pipeline:
            
            1. **Data Collection** - From environmental sensors
            2. **Preprocessing** - Scaling, feature engineering
            3. **Prediction** - Using the trained model
            4. **Alert Generation** - Based on thresholds
            5. **Visualization** - Interactive dashboard
            """)
        
        # System architecture diagram (simplified ASCII)
        st.markdown("""
        ### System Architecture
        
        ```
        ┌───────────────────┐     ┌───────────────────┐
        │                   │     │                   │
        │  Sensor Data      │────▶│  Preprocessing    │
        │  Collection       │     │  & Feature Eng.   │
        │                   │     │                   │
        └───────────────────┘     └────────┬──────────┘
                                           │
                                           ▼
        ┌───────────────────┐     ┌───────────────────┐
        │                   │     │                   │
        │  Dashboard        │◀────│  ML Prediction    │
        │  Visualization    │     │  Engine           │
        │                   │     │                   │
        └───────────────────┘     └───────────────────┘
        ```
        
        ### Future Development Plans
        
        - Integration with real IoT sensors for live data
        - Mobile app for alerts and remote monitoring
        - Enhanced model training with real-world data
        - Multi-location support for large farm operations
        - Expanded disease prediction coverage
        """)
    
    # Footer
    st.markdown("""
    <div style="margin-top: 50px; text-align: center; color: #888;">
        <hr>
        <p>Poultry Disease Prediction System | Developed with ❤️ for poultry farmers</p>
    </div>
    """, unsafe_allow_html=True)

# Import our model evaluation functions
from model_metrics import evaluate_model

# Import notification service 
from notification_service import send_disease_notification

# Function to render the model evaluation page
def render_model_evaluation():
    """Render the model evaluation page"""
    st.header("📈 Model Evaluation & Metrics")
    
    st.markdown("""
    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
        <h3 style="margin-top: 0;">🧪 Model Performance Analysis</h3>
        <p>This page provides detailed metrics about the poultry disease prediction model, 
        including accuracy, precision, recall, confusion matrix, and feature importance.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Add button to run evaluation
    if st.button("Run Model Evaluation", key="run_evaluation"):
        with st.spinner("Evaluating model performance..."):
            # Run the evaluation
            try:
                eval_results = evaluate_model()
                
                if "error" in eval_results:
                    st.error(eval_results["error"])
                else:
                    # Store the results in session state
                    st.session_state.eval_results = eval_results
                    st.success("Evaluation completed successfully!")
            except Exception as e:
                st.error(f"Error during evaluation: {str(e)}")
    
    # Show evaluation results if available
    if 'eval_results' in st.session_state:
        results = st.session_state.eval_results
        
        # Create tabs for different aspects of evaluation
        metrics_tab, confusion_tab, features_tab = st.tabs([
            "📊 Performance Metrics", 
            "🔄 Confusion Matrix", 
            "🔍 Feature Importance"
        ])
        
        with metrics_tab:
            # Overall metrics
            st.subheader("Overall Model Performance")
            
            # Create a visual metrics display
            col1, col2, col3, col4 = st.columns(4)
            
            col1.metric(
                "Accuracy", 
                f"{results['accuracy']:.2%}", 
                "Target: 95%"
            )
            
            col2.metric(
                "Precision", 
                f"{results['weighted_precision']:.2%}"
            )
            
            col3.metric(
                "Recall", 
                f"{results['weighted_recall']:.2%}"
            )
            
            col4.metric(
                "F1 Score", 
                f"{results['weighted_f1']:.2%}"
            )
            
            # Metrics by disease class
            st.subheader("Performance by Disease Class")
            
            # Plot the metrics figure
            st.pyplot(results["metrics_fig"])
            
            # Display the metrics table
            st.dataframe(
                results["metrics_by_class"],
                column_config={
                    "Disease": st.column_config.TextColumn("Disease"),
                    "Precision": st.column_config.NumberColumn(
                        "Precision", 
                        format="%.2f"
                    ),
                    "Recall": st.column_config.NumberColumn(
                        "Recall", 
                        format="%.2f"
                    ),
                    "F1-Score": st.column_config.NumberColumn(
                        "F1-Score", 
                        format="%.2f"
                    ),
                    "Support": st.column_config.NumberColumn(
                        "Support", 
                        format="%d",
                        help="Number of samples in test set"
                    )
                },
                hide_index=True
            )
            
            st.markdown("""
            ### Interpreting the Metrics
            
            - **Precision**: When the model predicts a disease, how often is it correct?
            - **Recall**: Out of all the actual cases of a disease, how many were correctly predicted?
            - **F1-Score**: Harmonic mean of precision and recall, balancing both metrics
            - **Support**: Number of samples of this class in the test set
            """)
        
        with confusion_tab:
            st.subheader("Confusion Matrix")
            
            st.markdown("""
            The confusion matrix shows how many samples were classified correctly vs. incorrectly.
            
            - Rows: Actual disease
            - Columns: Predicted disease
            - Diagonal: Correct predictions
            - Off-diagonal: Incorrect predictions
            """)
            
            # Display the confusion matrix
            st.pyplot(results["confusion_matrix_fig"])
            
            # Add information about misclassifications
            st.subheader("Common Misclassifications")
            
            # Find misclassifications from confusion matrix
            cm = results["confusion_matrix"]
            disease_names = [results["disease_id_to_name"].get(i, f"Unknown ({i})") for i in results["present_classes"]]
            
            misclassifications = []
            for i in range(len(cm)):
                for j in range(len(cm)):
                    if i != j and cm[i, j] > 0:
                        misclassifications.append({
                            "Actual": disease_names[i],
                            "Predicted": disease_names[j],
                            "Count": int(cm[i, j]),
                            "Percentage": f"{(cm[i, j] / cm[i].sum()) * 100:.1f}%"
                        })
            
            if misclassifications:
                misclass_df = pd.DataFrame(misclassifications)
                st.dataframe(misclass_df.sort_values("Count", ascending=False), hide_index=True)
                
                # Add explanations for top misclassifications
                st.markdown("""
                #### Possible Reasons for Misclassifications
                
                1. **Similar Environmental Patterns**: Some diseases share similar environmental triggers
                2. **Overlapping Symptoms**: Different diseases can present with similar symptoms
                3. **Age/Season Overlap**: Diseases that affect similar age groups or seasons
                """)
            else:
                st.info("No misclassifications found! Perfect classification.")
        
        with features_tab:
            st.subheader("Feature Importance")
            
            st.markdown("""
            Feature importance shows which environmental parameters have the strongest influence on disease prediction.
            Higher importance indicates a stronger role in determining the prediction outcome.
            """)
            
            # Display feature importance plot
            st.pyplot(results["feature_importance_fig"])
            
            # Display top 10 features in a table
            st.subheader("Top 10 Most Important Features")
            top_features = results["feature_importance"].head(10)
            
            # Format for display
            st.dataframe(
                top_features,
                column_config={
                    "Feature": st.column_config.TextColumn("Feature"),
                    "Importance": st.column_config.ProgressColumn(
                        "Importance",
                        min_value=0,
                        max_value=top_features["Importance"].max(),
                        format="%.4f"
                    )
                },
                hide_index=True
            )
            
            st.markdown("""
            ### Feature Interpretation
            
            - **Temperature features**: Direct impact on heat stress and respiratory conditions
            - **Humidity features**: Affects fungal growth and respiratory health
            - **CO2/Ammonia features**: Related to air quality and ventilation
            - **Season-related features**: Capture seasonal disease patterns
            - **Bird age features**: Different ages have different disease susceptibilities
            """)
    else:
        st.info("Click 'Run Model Evaluation' to generate performance metrics for the model.")

# Function to render the settings page
def render_settings():
    """Render the settings page"""
    st.header("⚙️ System Settings")
    
    st.markdown("""
    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
        <h3 style="margin-top: 0;">📧 Automatic Email Notification System</h3>
        <p>The system is configured to automatically send notifications to <b>jenniearul@gmail.com</b> 
        when disease predictions are made with high confidence.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Email notification information
    st.info("Email notifications are automatically enabled. No manual configuration required.")
    
    # Show notification settings
    st.subheader("Notification Settings")
    
    # Display current notification settings
    st.markdown("""
    #### Current Configuration
    
    **Notification Recipient:** jenniearul@gmail.com
    
    **Notification Triggers:**
    - Disease predictions with confidence over 70%
    - Only for alerts with level 2 (Alert) or 3 (Critical)
    - Excludes "Healthy" predictions
    
    **Notification Content:**
    - Disease name and prediction confidence
    - Current environmental conditions
    - Recommended actions based on the disease
    """)
    
    # Simple form for notification threshold
    with st.form("notification_settings_form"):
        notification_threshold = st.slider(
            "Disease Confidence Threshold", 
            min_value=0.5, 
            max_value=1.0, 
            value=0.7, 
            step=0.05,
            help="Only send notifications for diseases predicted with confidence above this threshold"
        )
        
        submit_button = st.form_submit_button("Update Threshold")
        
        if submit_button:
            # Save to session state
            if 'email_settings' not in st.session_state:
                st.session_state.email_settings = {}
            
            st.session_state.email_settings['notification_threshold'] = notification_threshold
            st.success("Notification threshold updated successfully!")

# Main application logic
if page == "Dashboard":
    render_dashboard()
elif page == "Manual Prediction":
    render_manual_prediction()
elif page == "Model Evaluation":
    render_model_evaluation()
elif page == "Settings":
    render_settings()
else:  # About
    render_about()
