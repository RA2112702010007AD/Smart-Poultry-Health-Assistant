# Poultry Disease Prediction Model Training Script
# This script implements a machine learning model to predict poultry diseases
# based on environmental sensor data (temperature, humidity, CO2, and ammonia levels).

# Data manipulation and analysis
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pickle
import os

# Machine learning libraries
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import KNNImputer, SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
import xgboost as xgb

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import ListedColormap

# Import utility functions
from utils import generate_synthetic_data, get_disease_ids_and_names, thresholds

# Warnings
import warnings
warnings.filterwarnings('ignore')

# Set plot style
plt.style.use('ggplot')
sns.set(style="whitegrid")

# Random seed for reproducibility
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

def print_header(text):
    """Print a formatted header"""
    print("\n" + "=" * 80)
    print(f" {text} ".center(80, "="))
    print("=" * 80 + "\n")

print_header("1. Generating Synthetic Training Data")

# Generate synthetic data for model training (using a smaller sample for faster execution)
train_data = generate_synthetic_data(n_samples=1000, 
                                     start_date="2023-01-01", 
                                     end_date="2023-12-31")

print(f"Generated {len(train_data)} synthetic data points")
print(f"Data columns: {train_data.columns.tolist()}")
print(f"Unique diseases in data: {train_data['disease_name'].unique()}")
print(f"Disease distribution:\n{train_data['disease_name'].value_counts()}")

print_header("2. Data Preprocessing and Feature Engineering")

# Fill missing values
print("Filling missing values...")
for col in ['temperature', 'humidity', 'co2', 'ammonia']:
    if train_data[col].isna().sum() > 0:
        print(f"Filling {train_data[col].isna().sum()} missing values in {col}")
        train_data[col] = train_data[col].fillna(train_data[col].mean())

# Create additional features from existing data

# Time-based features
print("Creating time-based features...")
train_data['hour'] = train_data['timestamp'].dt.hour
train_data['day'] = train_data['timestamp'].dt.day
train_data['month'] = train_data['timestamp'].dt.month
train_data['dayofweek'] = train_data['timestamp'].dt.dayofweek

# Calculate Temperature-Humidity Index (THI)
print("Calculating Temperature-Humidity Index (THI)...")
train_data['THI'] = (0.8 * train_data['temperature'] + 
                     (train_data['humidity'] / 100) * 
                     (train_data['temperature'] - 14.4) + 46.4)

# Create rolling averages and standard deviations
# Since data is not time-series ordered in our synthetic case, we'll simulate this
print("Creating rolling statistics features...")
for feature in ['temperature', 'humidity', 'co2', 'ammonia', 'THI']:
    # For demonstration, we'll create pseudo rolling features based on nearby records
    # In real data, you'd use proper time-ordered rolling windows
    train_data[f'{feature}_rolling_avg_6h'] = train_data[feature]
    train_data[f'{feature}_rolling_std_6h'] = train_data.groupby('season')[feature].transform('std')

# Create threshold breach indicators
print("Creating threshold breach indicators...")
train_data['temp_above_threshold'] = (train_data['temperature'] > thresholds['temperature']['max']).astype(int)
train_data['co2_above_threshold'] = (train_data['co2'] > thresholds['co2']['max']).astype(int)
train_data['ammonia_above_threshold'] = (train_data['ammonia'] > thresholds['ammonia']['max']).astype(int)
train_data['humidity_below_threshold'] = (train_data['humidity'] < thresholds['humidity']['min']).astype(int)
train_data['humidity_above_threshold'] = (train_data['humidity'] > thresholds['humidity']['max']).astype(int)

# Calculate daily averages (group by date)
print("Calculating daily averages...")
daily_avg = train_data.groupby(train_data['timestamp'].dt.date).agg({
    'temperature': 'mean',
    'humidity': 'mean',
    'co2': 'mean',
    'ammonia': 'mean'
}).reset_index()

daily_avg.columns = ['date', 'daily_avg_temperature', 'daily_avg_humidity', 
                      'daily_avg_co2', 'daily_avg_ammonia']
train_data['date'] = train_data['timestamp'].dt.date
train_data = train_data.merge(daily_avg, on='date', how='left')
train_data.drop('date', axis=1, inplace=True)

# One-hot encode categorical features
print("One-hot encoding categorical features...")
train_data = pd.get_dummies(train_data, columns=['season'], prefix='season')

# Extract features and target
X = train_data.drop(['timestamp', 'disease_id', 'disease_name'], axis=1)
y = train_data['disease_id']

print(f"Final feature set contains {X.shape[1]} features")

print_header("3. Model Training and Evaluation")

# Filter out classes with too few samples (issue with Hurdlling having only 1 sample)
print("Filtering out rare disease classes with too few samples...")
class_counts = train_data['disease_id'].value_counts()
classes_to_keep = class_counts[class_counts >= 5].index
mask = train_data['disease_id'].isin(classes_to_keep)
X_filtered = X[mask]
y_filtered = y[mask]

print(f"Removed rare classes. New sample count: {len(X_filtered)}")

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_filtered, y_filtered, test_size=0.2, random_state=RANDOM_SEED, stratify=y_filtered
)

print(f"Training set: {X_train.shape[0]} samples")
print(f"Testing set: {X_test.shape[0]} samples")

# Create a preprocessing pipeline
print("Setting up preprocessing pipeline...")
preprocessor = StandardScaler()

# Scale the features
X_train_scaled = preprocessor.fit_transform(X_train)
X_test_scaled = preprocessor.transform(X_test)

print("Training multiple models...")
# Training multiple models for comparison
models = {
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=RANDOM_SEED),
    "Gradient Boosting": GradientBoostingClassifier(n_estimators=100, random_state=RANDOM_SEED),
    "XGBoost": xgb.XGBClassifier(n_estimators=100, random_state=RANDOM_SEED)
}

# Train and evaluate each model
best_accuracy = 0
best_model_name = None
best_model = None

print("\nModel Comparison:")
print("-" * 60)
print(f"{'Model':<20} {'Accuracy':<10} {'Cross-Val Accuracy':<20}")
print("-" * 60)

for name, model in models.items():
    # Train the model
    model.fit(X_train_scaled, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test_scaled)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    
    # Perform cross-validation
    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5)
    cv_accuracy = np.mean(cv_scores)
    
    print(f"{name:<20} {accuracy:.4f}     {cv_accuracy:.4f} ± {np.std(cv_scores):.4f}")
    
    # Keep track of the best model
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model_name = name
        best_model = model

print("-" * 60)
print(f"Best Model: {best_model_name} with accuracy: {best_accuracy:.4f}")

print_header("4. Fine-Tuning the Best Model")

# Hyperparameter tuning for the best model - use a simpler grid for faster execution
if best_model_name == "Random Forest":
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [10, 20],
    }
    
    base_model = RandomForestClassifier(random_state=RANDOM_SEED)
    
elif best_model_name == "Gradient Boosting":
    param_grid = {
        'n_estimators': [100, 200],
        'learning_rate': [0.1, 0.2],
    }
    
    base_model = GradientBoostingClassifier(random_state=RANDOM_SEED)
    
else:  # XGBoost
    param_grid = {
        'n_estimators': [100, 200],
        'learning_rate': [0.1, 0.2],
    }
    
    base_model = xgb.XGBClassifier(random_state=RANDOM_SEED)

print(f"Performing grid search for {best_model_name}...")
grid_search = GridSearchCV(
    base_model, param_grid, cv=3, scoring='accuracy', verbose=1, n_jobs=-1
)
grid_search.fit(X_train_scaled, y_train)

print(f"Best parameters: {grid_search.best_params_}")
print(f"Best cross-validation accuracy: {grid_search.best_score_:.4f}")

# Evaluate the tuned model
tuned_model = grid_search.best_estimator_
y_pred_tuned = tuned_model.predict(X_test_scaled)
tuned_accuracy = accuracy_score(y_test, y_pred_tuned)
print(f"Tuned model accuracy on test set: {tuned_accuracy:.4f}")

print_header("5. Model Evaluation and Analysis")

# Plot confusion matrix
print("Generating confusion matrix...")
cm = confusion_matrix(y_test, y_pred_tuned)
disease_id_to_name = get_disease_ids_and_names()

# Get class labels
class_names = [disease_id_to_name.get(id, f"Unknown ({id})") for id in sorted(np.unique(y))]

plt.figure(figsize=(15, 12))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=class_names, yticklabels=class_names)
plt.title('Confusion Matrix', fontsize=16)
plt.xlabel('Predicted', fontsize=14)
plt.ylabel('Actual', fontsize=14)
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.tight_layout()
plt.savefig('confusion_matrix.png')
print("Confusion matrix saved as 'confusion_matrix.png'")

# Print classification report
print("\nClassification Report:")
class_report = classification_report(y_test, y_pred_tuned, 
                                    target_names=class_names,
                                    output_dict=True)

# Convert to DataFrame for better display
report_df = pd.DataFrame(class_report).transpose()
print(report_df.round(3))

# Calculate feature importance
if hasattr(tuned_model, 'feature_importances_'):
    print("\nFeature Importance:")
    feature_importance = pd.DataFrame({
        'Feature': X.columns,
        'Importance': tuned_model.feature_importances_
    })
    feature_importance = feature_importance.sort_values('Importance', ascending=False)
    
    plt.figure(figsize=(12, 8))
    sns.barplot(x='Importance', y='Feature', data=feature_importance.head(20))
    plt.title('Top 20 Feature Importances')
    plt.tight_layout()
    plt.savefig('feature_importance.png')
    print("Feature importance plot saved as 'feature_importance.png'")
    
    print(feature_importance.head(20))

print_header("6. Saving the Model")

# Get the list of feature names
feature_names = X.columns.tolist()

# Save the model and associated data
model_data = {
    'model': tuned_model,
    'scaler': preprocessor,
    'features': feature_names,
    'disease_id_to_name': disease_id_to_name,
    'thresholds': thresholds
}

with open('poultry_disease_prediction_model.pkl', 'wb') as f:
    pickle.dump(model_data, f)

print("Model saved successfully to 'poultry_disease_prediction_model.pkl'")
print(f"Achieved accuracy: {tuned_accuracy:.4f} ({tuned_accuracy*100:.2f}%)")

if tuned_accuracy >= 0.95:
    print("✅ Successfully achieved the target of at least 95% accuracy!")
else:
    print(f"⚠️ Target accuracy of 95% not reached. Current accuracy: {tuned_accuracy*100:.2f}%")

print_header("7. Summary")
print(f"Model: {best_model_name} (tuned)")
print(f"Accuracy: {tuned_accuracy:.4f} ({tuned_accuracy*100:.2f}%)")
print(f"Number of features: {len(feature_names)}")
print(f"Number of classes: {len(class_names)}")
print(f"Training samples: {X_train.shape[0]}")
print(f"Testing samples: {X_test.shape[0]}")
print("\nThe model is now ready to make predictions in the Streamlit application.")