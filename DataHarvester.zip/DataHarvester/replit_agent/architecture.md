# Architecture Documentation

## Overview

This repository contains a Poultry Disease Prediction System that uses machine learning to predict diseases in poultry based on environmental sensor data. The system consists of a machine learning model developed in a Jupyter notebook and a web-based dashboard built with Streamlit for visualizing predictions and monitoring environmental conditions.

The application is designed to help poultry farmers detect potential disease outbreaks early by analyzing various environmental parameters such as temperature, humidity, CO2 levels, and ammonia levels collected from sensors in poultry houses.

## System Architecture

The system follows a simple architecture with two main components:

1. **Model Training Pipeline**: A Jupyter notebook environment for data processing, model training, and evaluation
2. **Web Dashboard**: A Streamlit application that serves as the user interface for the prediction system

### Architecture Diagram

```
┌───────────────────┐     ┌───────────────────┐
│                   │     │                   │
│  Model Training   │────▶│  Trained Model    │
│  (Jupyter)        │     │  (Pickle File)    │
│                   │     │                   │
└───────────────────┘     └────────┬──────────┘
                                  │
                                  ▼
                          ┌───────────────────┐
                          │                   │
                          │  Web Dashboard    │
                          │  (Streamlit)      │
                          │                   │
                          └───────────────────┘
```

## Key Components

### 1. Model Training Pipeline

Located in: `poultry_disease_prediction.ipynb`

This component is responsible for:
- Data preprocessing and feature engineering
- Model selection and training
- Model evaluation and validation
- Serializing the trained model and associated data

The pipeline uses scikit-learn and XGBoost libraries to build a classification model that predicts poultry diseases based on environmental sensor data. The trained model, along with the feature scaler and disease mapping information, is serialized to a pickle file (`poultry_disease_prediction_model.pkl`).

### 2. Web Dashboard

Located in: `app.py`

The web dashboard is built using Streamlit and provides:
- A user interface for visualizing predictions
- Environmental parameter monitoring
- Threshold-based alerts for critical conditions

The dashboard loads the trained model from the pickle file and uses it to make predictions based on current environmental data. It also provides visualization capabilities using matplotlib and seaborn for data analysis.

### 3. Utility Functions

Located in: `utils.py`

This module contains helper functions and constants used by both the model training pipeline and the web dashboard:
- Standard thresholds for environmental parameters
- Information about different poultry diseases including symptoms and causes
- Data processing utilities

## Data Flow

1. **Model Training**:
   - Environmental sensor data is processed in the Jupyter notebook
   - Features are extracted and preprocessed (scaling, imputation)
   - Multiple models are evaluated (Random Forest, Gradient Boosting, XGBoost)
   - The best performing model is selected and serialized to a pickle file

2. **Prediction Flow**:
   - The Streamlit app loads the trained model and associated data
   - Current environmental parameters are collected (or input by the user)
   - The model predicts potential diseases based on the parameters
   - Results are displayed in the dashboard with recommendations

3. **Monitoring Flow**:
   - Environmental parameters are compared against predefined thresholds
   - Alerts are generated if parameters exceed safe limits
   - Historical data is visualized to identify trends

## External Dependencies

The application relies on the following external libraries:

### Data Processing and Analysis
- pandas
- numpy

### Machine Learning
- scikit-learn
- xgboost

### Visualization
- matplotlib
- seaborn

### Web Dashboard
- streamlit

## Deployment Strategy

The application is configured for deployment using Replit's infrastructure, as evident from the `.replit` configuration file. The deployment strategy includes:

1. **Containerized Deployment**:
   - The application is packaged with all its dependencies
   - Configured to run on Python 3.11

2. **Auto-scaling**:
   - The deploymentTarget is set to "autoscale" in the .replit file
   - This allows the application to scale based on demand

3. **Port Configuration**:
   - Streamlit server runs on port 5000 internally
   - Mapped to external port 80 for public access

4. **Server Configuration**:
   - Streamlit is configured to run in headless mode (no browser auto-launch)
   - Bound to address 0.0.0.0 to accept connections from any IP

The workflow is set up to automatically start the Streamlit server when the project is run, making it accessible via a web browser.

## Future Considerations

1. **Database Integration**:
   - Currently, the system uses pickle files for model storage
   - A database could be added for storing historical sensor data and predictions

2. **Real-time Sensor Integration**:
   - The system could be enhanced to directly connect with IoT sensors in poultry houses

3. **Extended Monitoring Capabilities**:
   - Additional visualization and analytics features could be added
   - Alert notifications via email or SMS could be implemented

4. **Model Retraining**:
   - Implementing automated retraining pipelines to improve model accuracy over time