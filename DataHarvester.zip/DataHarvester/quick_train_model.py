# Poultry Disease Prediction Model Training Script (Simplified Version)
# This script implements a simplified training process for the poultry disease prediction model

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pickle
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Import utility functions
from utils import get_disease_ids_and_names, thresholds

# Set random seed for reproducibility
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

print("Generating synthetic data...")

# Generate synthetic data for training
timestamps = [datetime.now() - timedelta(hours=i) for i in range(500)]
timestamps.reverse()  # So they go from past to present

# Set up disease categories
disease_ids = [0] * 250 + [1] * 50 + [2] * 50 + [7] * 50 + [9] * 50 + [12] * 50
np.random.shuffle(disease_ids)
disease_ids = disease_ids[:500]  # Make sure we have 500 samples

# Get disease names
disease_id_to_name = get_disease_ids_and_names()
disease_names = [disease_id_to_name.get(id, f"Unknown ({id})") for id in disease_ids]

# Generate environmental conditions based on disease
temperatures = []
humidities = []
co2_levels = []
ammonia_levels = []
bird_ages = []
seasons = []

for i, disease_id in enumerate(disease_ids):
    if disease_id == 0:  # Healthy
        temp = np.random.uniform(26, 28)
        humidity = np.random.uniform(50, 60)
        co2 = np.random.uniform(1000, 3000)
        ammonia = np.random.uniform(5, 15)
    elif disease_id == 1:  # Pneumonia/Fungal
        temp = np.random.uniform(30, 34)
        humidity = np.random.uniform(70, 90)
        co2 = np.random.uniform(2500, 4000)
        ammonia = np.random.uniform(10, 25)
    elif disease_id == 2:  # Omphilitispis
        temp = np.random.uniform(28, 33)
        humidity = np.random.uniform(65, 85)
        co2 = np.random.uniform(3000, 4500)
        ammonia = np.random.uniform(15, 30)
    elif disease_id == 7:  # CRD
        temp = np.random.uniform(30, 38)
        humidity = np.random.uniform(40, 70)
        co2 = np.random.uniform(2500, 4500)
        ammonia = np.random.uniform(20, 40)
    elif disease_id == 9:  # Heat Stroke
        temp = np.random.uniform(33, 42)
        humidity = np.random.uniform(40, 70)
        co2 = np.random.uniform(2000, 5000)
        ammonia = np.random.uniform(15, 30)
    elif disease_id == 12:  # New Castle
        temp = np.random.uniform(28, 36)
        humidity = np.random.uniform(50, 80)
        co2 = np.random.uniform(2500, 4500)
        ammonia = np.random.uniform(20, 35)
    else:  # Other diseases (shouldn't happen in this simplified case)
        temp = np.random.uniform(25, 35)
        humidity = np.random.uniform(50, 80)
        co2 = np.random.uniform(2000, 4500)
        ammonia = np.random.uniform(10, 30)
    
    # Add some random noise
    temp += np.random.normal(0, 0.5)
    humidity += np.random.normal(0, 2)
    co2 += np.random.normal(0, 100)
    ammonia += np.random.normal(0, 1)
    
    # Clamp to reasonable ranges
    temperatures.append(max(15, min(45, temp)))
    humidities.append(max(30, min(95, humidity)))
    co2_levels.append(max(400, min(6000, co2)))
    ammonia_levels.append(max(0, min(50, ammonia)))
    
    # Random bird age (1-40 days)
    bird_ages.append(np.random.randint(1, 41))
    
    # Random season
    seasons.append(np.random.choice(['summer', 'winter', 'rainy', 'spring']))

# Create training DataFrame
data = pd.DataFrame({
    'timestamp': timestamps,
    'temperature': temperatures,
    'humidity': humidities,
    'co2': co2_levels,
    'ammonia': ammonia_levels,
    'bird_age': bird_ages,
    'season': seasons,
    'disease_id': disease_ids,
    'disease_name': disease_names
})

print(f"Generated {len(data)} samples for training")
print(f"Disease distribution:\n{data['disease_name'].value_counts()}")

# Process data
print("\nPreprocessing data and creating features...")

# One-hot encode season
data = pd.get_dummies(data, columns=['season'], prefix='season')

# Create THI feature
data['THI'] = (0.8 * data['temperature'] + 
               (data['humidity'] / 100) * 
               (data['temperature'] - 14.4) + 46.4)

# Create threshold breach indicators
data['temp_above_threshold'] = (data['temperature'] > thresholds['temperature']['max']).astype(int)
data['co2_above_threshold'] = (data['co2'] > thresholds['co2']['max']).astype(int)
data['ammonia_above_threshold'] = (data['ammonia'] > thresholds['ammonia']['max']).astype(int)
data['humidity_below_threshold'] = (data['humidity'] < thresholds['humidity']['min']).astype(int)
data['humidity_above_threshold'] = (data['humidity'] > thresholds['humidity']['max']).astype(int)

# Extract features and target
X = data.drop(['timestamp', 'disease_id', 'disease_name'], axis=1)
y = data['disease_id']

print(f"Created {X.shape[1]} features")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_SEED, stratify=y
)

print(f"Training set: {X_train.shape[0]} samples")
print(f"Testing set: {X_test.shape[0]} samples")

# Scale features
print("\nTraining model...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train model (Random Forest)
model = RandomForestClassifier(n_estimators=200, random_state=RANDOM_SEED)
model.fit(X_train_scaled, y_train)

# Evaluate
y_pred = model.predict(X_test_scaled)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Save model
feature_names = X.columns.tolist()
model_data = {
    'model': model,
    'scaler': scaler,
    'features': feature_names,
    'disease_id_to_name': disease_id_to_name,
    'thresholds': thresholds
}

with open('poultry_disease_prediction_model.pkl', 'wb') as f:
    pickle.dump(model_data, f)

print("\nModel saved successfully to 'poultry_disease_prediction_model.pkl'")

# Check if accuracy meets target
if accuracy >= 0.95:
    print("✅ Successfully achieved the target of at least 95% accuracy!")
else:
    print(f"⚠️ Target accuracy of 95% not reached. Current accuracy: {accuracy*100:.2f}%")
    print("However, the model is still useful for demonstrations in the web app.")

print("\nThe model is now ready to make predictions in the Streamlit application.")